// Declarative pipeline script for Production Deployment //
// Note:  Required to change only the Groovy Global Variables //
// ********************* VERSION: 1 *************************//

// Importing all hudson libraries //
import hudson.model.*

// Declaring Pipeline environmental variables //

def env='prod' // Environment //
def app_name='tigergraph' // Name of the application //
def deployment_host='beta-tigergraph1' // Host name/ Group name of the deployment server //
def become_user='dmadeployer' // Deployer User //
def repo_name='dma-tigergraph' // Code repository name //
def remote_origin='origin' // NO ACTION REQUIRED : Remote origin //
def branch_name='release/prod'  // GitHub Branch Name //
def jenkins_host='http://10.74.198.189:8080' //Hostname of Jenkins - To get console o/p //
def dest_path='/tmp/dma-tigergraph' //Destination server path of your data to be deployed //
def git_creds='4d39b737-9c62-4a5f-95f4-c4589b9ac981' // GitHub credentials- Change ID as per Jenkins server https://jenkins_url/credentials/ //
def code_repo_name='git@github.com:HBOCodeLabs/dma-tigergraph.git' // SSH Repository of deploy repo //
def admin_repo='git@github.com:HBOCodeLabs/dma-ansible-dapadmin.git' //Admin Ansible repo here //
def admin_repo_python='git@github.com:HBOCodeLabs/dma-python-dapadmin.git' // Admin Python Repo here //

def DL_EMAIL='DAPOperationsSupport@hbo.com' // NO ACTION REQUIRED : Email ID to send pipeline notification //
def GIT_COMMIT // NO ACTION REQUIRED : For Git Commit ID assignment //
def GIT_TAG // NO ACTION REQUIRED : For Git tag version assignment //
def GIT_TAG_OLD // NO ACTION REQUIRED : For Git tag older version assignment //
def LOG_READ // NO ACTION REQUIRED : For cosole log assignment //
def COMMIT_ONELINER // NO ACTION REQUIRED : For Commit info assignment //

//End of Variables.//

// Declarative Pipeline starts here //
pipeline {
    agent any
    // Stages begins here //
    stages {
        
        // Stage for Git Branches Checkout //
        stage('Checkout Git Branch') {
           steps{  
               
             // Checkout Code repository under workspace //
             checkout(
                    poll:true,
                    changelog:false,
                    scm: [
                        $class:'GitSCM',
                        branches: [[name:"${branch_name}"]],
                        clean:true,
                        extensions: [[$class: 'DisableRemotePoll'],
                        [$class: 'PathRestriction', excludedRegions: '*'],
                        [$class: 'LocalBranch', localBranch: "**"]],
                        submoduleCfg: [],
                        userRemoteConfigs: [[url: "${code_repo_name}"]],
                        credentialsId: "${git_creds}",
                    ])
                    
             // Create Ansible admin directory and do a checkout from master //
             dir('dma-ansible-dapadmin') {
                 checkout(
                    poll:false,
                    changelog:false,
                    scm: [
                        $class:'GitSCM',
                        branches: [[name:'master']],
                        clean:true,
                        extensions: [[$class: 'DisableRemotePoll'],
                        [$class: 'PathRestriction', excludedRegions: '*'],
                        [$class: 'LocalBranch', localBranch: "**"]],
                        submoduleCfg: [],
                        userRemoteConfigs: [[url: "${admin_repo}"]],
                        credentialsId: "${git_creds}",
                    ]) 
                    }
                    
             // Create Python admin directory and do a checkout from master //
             dir('dma-python-dapadmin') {
                 checkout(
                    poll:false,
                    changelog:false,
                    scm: [
                        $class:'GitSCM',
                        branches: [[name:'nidhinnru-patch-34']],
                        clean:true,
                        extensions: [[$class: 'DisableRemotePoll'],
                        [$class: 'PathRestriction', excludedRegions: '*'], 
                        [$class: 'LocalBranch', localBranch: "**"]],
                        submoduleCfg: [],
                        userRemoteConfigs: [[url: "${admin_repo_python}"]],
                        credentialsId: "${git_creds}",
                    ]) 
                    }
            }
        }
            
        // Stage to deploy the files to destination server //
       	stage('Deploy'){
		    steps {
                sh("set +x && echo 'DEPLOYBEGIN' && echo '******Deploying from release/${env} Branch to ${app_name} ${env} Environment******'")
                sh("set +x && ansible-playbook -i ${WORKSPACE}/dma-ansible-dapadmin/inventory.ini ./dma-ansible-dapadmin/sites.yml --limit '${deployment_host}' --tags clone_repo -e 'username=${become_user} reponame=${code_repo_name} destfolder=${dest_path} origin=${remote_origin} branchname=${branch_name}'")
                sh("set +x && echo 'Deployed Successfully to ${app_name} ${env} ${dest_path} path'")
		    }
       		}
        // Stage to tag the commit from release/prod branch, push to remote and tag with master branch //
       	stage('Git Tag'){
		    steps {
		       script {
		            // Tag the release //
                    sh '''
                    set +x
                    echo "***Proceeding to tag the Release***"
		            echo "-----------------------------------"
		            
                    #Get current hash and see if it already has a tag
                    GIT_COMMIT=`git rev-parse HEAD`
                    
                    #Get the highest tag number
                    VERSION=`git describe --abbrev=0 --tags`
                    echo "$VERSION" > old_version.txt
                    
                    #Only tag if no tag already (would be better if the git describe command above could have a silent option)
                    if [ -z `git describe --contains $GIT_COMMIT 2>/dev/null` ]; then
                       
                       VERSION=${VERSION:-'0.0.0'}

                       #Get number parts
                       MAJOR="${VERSION%%.*}"; VERSION="${VERSION#*.}"
                       MINOR="${VERSION%%.*}"; VERSION="${VERSION#*.}"
                       PATCH="${VERSION%%.*}"; VERSION="${VERSION#*.}"

                       #Increase version
                       PATCH=$((PATCH+1))

                       #Create new tag
                       NEW_TAG="$MAJOR.$MINOR.$PATCH"
                       echo "Latest version to be tagged: $NEW_TAG"
                       
                       git tag -a $NEW_TAG -m "Release Version: $NEW_TAG, Build No: ${BUILD_NUMBER}" 
                       git push --tags origin release/prod
                       echo "Successfully tagged $GIT_COMMIT with Version: $NEW_TAG"
                       echo "$NEW_TAG" > tag_version.txt

                    else
                       echo "NOTE: Already a tag on this commit ID '$GIT_COMMIT'"
                       echo "This pipeline has ran with the most recent tag Version $VERSION"  
                      
                    fi
                    echo "STAGEDONE"
                    '''
                    GIT_TAG = readFile 'tag_version.txt'
                    GIT_TAG_OLD = readFile 'old_version.txt'

		       }


		    }
       		}	
    }   
        //Post action determines Success or Failure and send notifications//
        post {
        always {
            script {
                 //Below "if condition" is for console log parsing//
                 if (currentBuild.currentResult == "FAILURE") {
                      sh("set +x && echo 'STAGEDONE'")
                 } else {
                      sh("set +x")
                 }
                 
                 //Getting credentials from Jenkins global credentials//
                 withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'jenkinsbdp', usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) { 
                 
                    //Create directory if doesn't exists, try catch to ignore errors//
                    try {
                        sh "mkdir ${WORKSPACE}/logs 2>&1 >/dev/null"
                     } catch (Exception e) {
                        echo 'Log Directory already exists'
                    }
                    
                    //Curl to get conosle output log//
                    sh "curl -k -o ${WORKSPACE}/logs/${app_name}_${BUILD_NUMBER}.log -u $USERNAME:$PASSWORD ${jenkins_host}/job/${JOB_NAME}/${BUILD_NUMBER}/consoleText"
                    
                    //Collecting git commit details//
                    GIT_COMMIT = sh(script: "git rev-parse HEAD", returnStdout: true).trim()
                    COMMIT_DETAILS = sh(script: "git show --pretty=fuller ${GIT_COMMIT} | tr -d '[:blank:]' | sed 's/commit/CommitID:/'", returnStdout: true).trim()
                    
                    //Read console log and store to variable//
                    LOG_READ = sh(script: "set +x && cat ${WORKSPACE}/logs/${app_name}_${BUILD_NUMBER}.log | sed -e '/DEPLOYBEGIN/p' -e '0,/DEPLOYBEGIN/d' | sed '/STAGEDONE/Q' | sed 's/set +x//'", returnStdout: true).trim()
                    COMMIT_ONELINER=sh(script: "set +x && echo '${COMMIT_DETAILS}' | xargs", returnStdout: true).trim()
                    ENV_CON=sh(script: "set +x && echo ${env} | tr 'a-z' 'A-Z'", returnStdout: true).trim()
                    
                    //Print commit details in console//
                    echo "----------------------------------------------------------"
                    echo "${COMMIT_DETAILS}"
                    echo "----------------------------------------------------------"
                    
                 }
                    
              }

            }
         //Send Success Notification//
         success {
            script {
                    echo "Sending user notification for Successful deployment."
                    echo "********************Summary*************************"
                    if (GIT_TAG) {
                        sh("set +x && AWS_PROFILE=dev python ./dma-python-dapadmin/ses/jenkins_notify_users.py --env ${ENV_CON} --branch ${branch_name} --commitdetails 'GitBranch:${branch_name} ${COMMIT_ONELINER}' --url '${BUILD_URL}console' --build_no ${BUILD_NUMBER} --logs '${LOG_READ}' --status 'prod-success' --buildname ${JOB_NAME} --tag '${GIT_TAG}' --email '${DL_EMAIL}'")
                    } else {
                        sh("set +x && AWS_PROFILE=dev python ./dma-python-dapadmin/ses/jenkins_notify_users.py --env ${ENV_CON} --branch ${branch_name} --commitdetails 'GitBranch:${branch_name} ${COMMIT_ONELINER}' --url '${BUILD_URL}console' --build_no ${BUILD_NUMBER} --logs '${LOG_READ}' --status 'prod-success' --buildname ${JOB_NAME} --tag '${GIT_TAG_OLD}' --email '${DL_EMAIL}'")
                    }
                    echo "************************END*************************" 
            }
         }
         //Send Failure Notification//
         failure {
            script {
                    echo "Sending user notification for failed deployment."
                    echo "*********************Summary********************"
                    sh("set +x && AWS_PROFILE=dev python ./dma-python-dapadmin/ses/jenkins_notify_users.py --env ${ENV_CON} --branch ${branch_name} --commitdetails 'GitBranch:${branch_name} ${COMMIT_ONELINER}' --url '${BUILD_URL}console' --build_no ${BUILD_NUMBER} --logs '${LOG_READ}' --status 'failure' --buildname ${JOB_NAME} --tag '1' --email ${DL_EMAIL}")
                    echo "**********************END***********************"       
            }
         }
        }      
    
  }
