import os
import sys
import csv
import time
import boto3
import logging
import optparse
import botocore
import snowflake.connector
from logging import handlers
from datetime import datetime, timedelta
from botocore.exceptions import ClientError
from logging.handlers import RotatingFileHandler


"""
Invoke Boto3 Client and Resources for S3 and IAM
"""
session = boto3.Session(profile_name='dev')
iam_client = boto3.client('iam')
s3_client = session.client('s3')
s3 = session.resource('s3')


def args_parse():
  """                     
  Argument parser function to receive all input variables
  """
  parser = optparse.OptionParser()
  parser.add_option("-e", "--env", action="store", dest="env", help="query string", default="")
  parser.add_option("-s", "--sfuser", action="store", dest="sf_user", help="query string", default="")
  parser.add_option("-p", "--sfpwd", action="store", dest="sf_pwd", help="query string", default="")
  parser.add_option("-w", "--wspath", action="store", dest="ws_path", help="query string", default="")
  options, args = parser.parse_args()
  return options

def init_logger():
  """
  Initializing logger function for log parsing
  """
  global logger
  logger = logging.getLogger('-')
  logger.setLevel(logging.DEBUG)
  formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
  ch = logging.StreamHandler()
  ch.setLevel(logging.DEBUG)
  ch.setFormatter(formatter)
  logger.addHandler(ch)
  wr_formatter = logging.Formatter("%(asctime)s-%(levelname)s-%(message)s<br/>")
  fh = handlers.RotatingFileHandler('offboard_user.log', maxBytes=(1048576*5), backupCount=7)
  fh.setFormatter(wr_formatter)
  logger.addHandler(fh)
  return logger

def send_email(tenant_file, users, build_logs):
  """
  Call AWS SES to send notification to DAP support.
  """
  logger.debug("Sending email notification")
  # The subject line for the email.
  SUBJECT = "DAP User Off-Board Summary"

  # The HTML body of the email.
  BODY_HTML = """<p>Hello,</p>
<p>Below are the users found in tenant off-boarding file.&nbsp;</p>
<p><span style="text-decoration: underline;"><strong>Tenant File name</strong></span>: %s</p>
<p><span style="text-decoration: underline;"><strong>Users: </strong></span></p>
<p><span style="color: #ff0000;">%s</span></p>
<p>&nbsp;</p>
<p><span style="text-decoration: underline;"><strong>Jenkins Build Logs: </strong></span></p>
<p><span style="background-color: #ffff99;">%s</span></p>
<p>&nbsp;</p>
<p><span style="font-size: 10.0pt;">Thanks &amp; Regards,</span></p>
<p><span style="font-size: 10.0pt;">MTIS-Applications And Platform Support | DAP Operation Team</span></p>
<p>&nbsp;</p>"""  %(tenant_file, users, build_logs)

  # The character encoding for the email.
  CHARSET = "UTF-8"

  # Create a new SES resource and specify a region.
  client = session.client('ses')

  # Try to send the email.
  try:
    #Provide the contents of the email.
    response = client.send_email(
        Destination={
            'ToAddresses': [
                'DAPOperationsSupport@hbo.com',
            ],
            'BccAddresses': [
                'DAPOperationsSupport@hbo.com',
            ],
        },
        Message={
            'Body': {
                'Html': {
                    'Charset': CHARSET,
                    'Data': BODY_HTML,
                },
            },
            'Subject': {
                'Charset': CHARSET,
                'Data': SUBJECT,
            },
        },
        Source='DAPOperationsSupport@hbo.com',
    )

  # Display an error if something goes wrong.	
  except ClientError as e:
    logger.error("An error occured while sending email to DAP Admin & Suppport. Error Response: {}".format(e.response['Error']['Message']))
  else:
    logger.debug("Email sent to DAP Admin & Support! Message ID: {}".format(response['MessageId']))

def iam_user_removal(email_id):
  """
  IAM user verification, access key deletion and User removal
  """
  options=args_parse()
  try:
   response = iam_client.get_user(
   UserName=email_id
   )
   id_from_aws=(response['User']['UserName'])
   if(id_from_aws==email_id):
     logger.debug("IAM User exists, proceeding user and access keys deletion, UserName: {}".format(email_id)) 
  except:
   logger.debug("An error occurred (NoSuchEntity) when calling the GetUser operation: The user with name {} cannot be found.!".format(email_id)) 
   id_from_aws='no_user'
  if(id_from_aws==email_id):
   try:
     access_id_response = iam_client.list_access_keys(UserName=email_id)
     for access_id in access_id_response['AccessKeyMetadata']:
      access_ids=(access_id['AccessKeyId'])
      logger.debug("Deleting IAM Access Key ID: {}".format(access_ids))
      del_key_response = iam_client.delete_access_key(
      UserName=email_id,
      AccessKeyId=access_ids
      )
      logger.debug("IAM key deletion response {}".format(del_key_response))
      if(del_key_response['ResponseMetadata']['HTTPStatusCode']==200):
        logger.debug("IAM key deletion is success, Access ID: {}".format(access_ids))
     List_of_Groups = iam_client.list_groups_for_user(UserName=email_id)
     for key in List_of_Groups['Groups']:
      group_name=key['GroupName']
      logger.debug("Removing user {} from group {}".format(email_id, group_name))
      response_ug = iam_client.remove_user_from_group(
        GroupName=group_name,
        UserName=email_id    
      )
      if(response_ug['ResponseMetadata']['HTTPStatusCode']==200):
        logger.debug("IAM user '{}' removed from the group '{}".format(email_id, group_name))
     del_response = iam_client.delete_user(
     UserName=email_id
     )
     logger.debug("IAM User delete response from AWS: {}".format(del_response))
     if(del_response['ResponseMetadata']['HTTPStatusCode']==200):
        logger.debug("IAM user deletion is success, UserName: {}".format(email_id))
   except:
     List_of_Groups = iam_client.list_groups_for_user(UserName=email_id)
     for key in List_of_Groups['Groups']:
      group_name=key['GroupName']
      logger.debug("Removing user {} from group {}".format(email_id, group_name))
      response_ug = iam_client.remove_user_from_group(
        GroupName=group_name,
        UserName=email_id    
      )
      if(response_ug['ResponseMetadata']['HTTPStatusCode']==200):
        logger.debug("IAM user '{}' removed from the group '{}".format(email_id, group_name))
     del_response = iam_client.delete_user(
     UserName=email_id
     )
     logger.debug("IAM User delete response from AWS: {}".format(del_response))
     if(del_response['ResponseMetadata']['HTTPStatusCode']==200):
        logger.debug("IAM user deletion is success, UserName: {}".format(email_id))
  else:
     logger.debug("No user with UserName: {} found for deletion, proceeding for snowflake user removal.".format(email_id))
     snowflake_user_drop(email_id)

def snowflake_user_drop(EMAIL_ID):
  """
  Removing Snowflake users
  """
  start = time.time()
  options=args_parse()  
  ctx = snowflake.connector.connect(
       		user=options.sf_user,
       		password=options.sf_pwd,
       		account="wc05407.us-east-1",
  )
  cs = ctx.cursor()
  cs.execute("use role ACCOUNTADMIN")
  count = cs.execute('DROP USER IF EXISTS "{}"'.format(EMAIL_ID))
  one_row = cs.fetchall()
  logger.debug("Snowflake response for user removal, UserName: {}, Response: {}!".format(EMAIL_ID, one_row))
  if(one_row[0]=="successfully dropped"):
    logger.debug("Snowflake user {} successfully removed!".format(EMAIL_ID))
  cs.close()
  ctx.close()
  return ctx

def s3_csv_file_check():
  """
  Checks if any latest tenant file available and invoke s3_download_formatter function
  """
  global Latest_File
  options=args_parse()
  Bucket_Name="hbo-dap-usersonoffboard"
  objects = s3_client.list_objects(Bucket='hbo-dap-usersonoffboard')
  for keys in objects["Contents"]:
   last_modified_date=(keys['LastModified'])
   f_modified_date=last_modified_date.strftime('%m/%d/%Y')
   present_date=datetime.now()
   current_date=present_date.strftime('%m/%d/%Y')
   if(f_modified_date==current_date):
    Latest_File=(keys['Key'])
    logger.debug("Latest file in S3 bucket 'hbo-dap-usersonoffboard' is {}, timestamp: {}".format(Latest_File, last_modified_date))
    if Latest_File in open("{}/tenant_fnames.txt".format(options.ws_path)).read():
       logger.debug("No latest tenant file uploaded in s3 bucket, skipping...")      
       sys.exit(0)
    else:
       s3_download_formatter(Bucket_Name, Latest_File)
       
def s3_download_formatter(bucket_name, file_name):
  """
  Downloads latest tenant file from s3 bucket and remove duplicates,
  parse email id and user name
  """
  global users
  users=[]
  try:
   s3.Bucket(bucket_name).download_file(file_name, file_name)
  except botocore.exceptions.ClientError as e:
   if e.response['Error']['Code'] == "404":
    logger.error("The object {s3-file} does not exist.!".format(file_name))
   else:
     raise
  #Remove duplicates from csv file
  with open(file_name) as f:
   data = list(csv.reader(f))
   new_data = [a for i, a in enumerate(data) if a not in data[:i]]
  with open(file_name, 'w') as t:
   write = csv.writer(t)
   write.writerows(new_data)
  #Parsing username and email id
  with open(file_name) as orders_file:
   reader = csv.reader(orders_file, delimiter=',')
   orders = list(reader)
   for order in orders:
    if order[2]:
      email_id=order[2]
      user_name=order[3]
      name=order[0]+' '+order[1]
      users.append(name+' - '+user_name+' - '+email_id)
      logger.debug("Email ID {} found in the Tenant file {}!".format(email_id, file_name))
      logger.debug("User ID {} found in the Tenant file {}!".format(user_name, file_name))
      iam_user_removal(email_id.lower())
    else:
      logger.error("Column not found in S3 bucket path 'hbo-dap-usersonoffboard' {}".format(file_name))

def main():
  init_logger()
  s3_csv_file_check() 
  options=args_parse()
  if(options.env=="prod"):
    with open("{}/tenant_fnames.txt".format(options.ws_path), "a") as text_file:
       text_file.write(Latest_File)
    with open("{}/offboard_user.log".format(options.ws_path), "r") as logfile:
       logdata=logfile.read()
       user_html_conversion=[]
       for i in users: user_html_conversion.append(i+'<br/>')
       if(len(users)!=0):
         send_email(Latest_File, (''.join(user_html_conversion)), logdata)


if __name__ == '__main__':
       main()

sys.exit()
