#!/bin/python

#####################################################################################################################
####################### Create IAM Users, Add users to groups and send them the Access keys #########################
#####################################################################################################################

import sys
import boto3
import logging
import optparse


def args_parse():
  """
  Argument parser function to receive all input variables
  """
  parser = optparse.OptionParser()
  parser.add_option('-g', '--group_name', action="store", dest="iam_group", help="group name", default="")
  parser.add_option("-e", "--env", action="store", dest="env", help="environment", default="")
  parser.add_option("-u", "--user", action="store", dest="iam_users", help="user name string", default="")
  parser.add_option("-s", "--email", action="store", dest="send_email", help="store email option", default="")
  options, args = parser.parse_args()
  return options

def init_logger():
  """
  Initializing logger function for effective logging
  """
  global logger
  logger = logging.getLogger('IAM')
  logger.setLevel(logging.DEBUG)
  ch = logging.StreamHandler()
  ch.setLevel(logging.DEBUG)
  formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
  ch.setFormatter(formatter)
  logger.addHandler(ch)
  return logger


def create_user(iam_username):
  """
  Create IAM user, access keys in AWS account
  """
  options=args_parse()
  iam = boto3.client('iam')
  logger.debug("Checking if user already exists, Username: {}".format(iam_username)) 
  try:
     usr_response = iam.get_user(
              UserName=iam_username
              )
     usr_status=(usr_response['ResponseMetadata']['HTTPStatusCode'])
  except Exception as p:
       logger.debug("User does not exists, proceeding to create new user, Response '{}'".format(p))
       logger.debug("Creating IAM User for Username: {}".format(iam_username))
       try:
         response = iam.create_user(
                  UserName=iam_username
                  )
         logger.debug("IAM user creation response {}".format(response))
         status_code=response['ResponseMetadata']['HTTPStatusCode']
       except Exception as e:
         logger.error("Unable to create user, Error response '{}'".format(e))
         return

       if(status_code==200):
         logger.debug("User '{}' created successfully.".format(iam_username))
         try:
             groups=[x.strip() for x in options.iam_group.split(',')]
             for group in groups:
              logger.debug("Proceeding to add user '{}' to '{}' group".format(iam_username, group))
              group_response = iam.add_user_to_group(
                         GroupName=group,
                         UserName=iam_username
                         )
              logger.debug("Response for adding group '{}' to user '{}', Response: {}".format(group, iam_username, group_response))
              status_code_group=group_response['ResponseMetadata']['HTTPStatusCode']
              if(status_code_group==200):
               logger.debug("Successfully added user '{}' to '{}' group".format(iam_username, group))
              else:
               logger.debug("Unable to add user '{}' to '{}' group".format(iam_username, group))
         except Exception as g:
              logger.error("Unable to add user to the groups, Error Response {}".format(g))

         try:
            key_response = iam.create_access_key(
                           UserName=iam_username
                            )
            logger.debug("IAM access keys creation response for user '{}': {}".format(iam_username, key_response))
            secret_access_key=(key_response['AccessKey']['SecretAccessKey'])
            access_key_id=(key_response['AccessKey']['AccessKeyId'])
            logger.debug("Access Key ID for user '{}': '{}'".format(iam_username, access_key_id))
            logger.debug("Secret Access key for user '{}': '{}'".format(iam_username, secret_access_key))
            if(options.send_email == "Yes"):
               send_keys_email(options.env.upper(), iam_username, secret_access_key, access_key_id)
         except Exception as f:
            logger.error("Unable to create Access key and Secret keys for user '{}', Error Response: {}".format(iam_username, f))

       else:
            logger.error("Unable to create IAM user, STATUS CODE: {}".format(status_code))

def send_keys_email(env, iam_user, secret_keys, access_keys):
  """
  AWS SES to send keys to the users.
  """
  logger.debug("Sending email notification")
  # The subject line for the email.
  SUBJECT = "{} AWS CLI Access Key - '{}'".format(env, iam_user)
  FIRST_NAME=iam_user.split(".")[0]

  # The HTML body of the email.
  BODY_HTML = """<p><span style="font-size: 10pt; font-family: verdana, geneva;">Hello %s,</span></p>
<p><span style="font-size: 10pt; font-family: verdana, geneva;">We have created an IAM user with CLI keys as per the request. Please find the Access ID and Secret Access keys below.</span></p>
<p><span style="font-size: 10pt; font-family: verdana, geneva;">Access_Key_ID: %s</span></p>
<p><span style="font-size: 10pt; font-family: verdana, geneva;">Secret_Access_Key: %s</span></p>
<p>&nbsp;</p>
<p><span style="font-size: 10pt; font-family: verdana, geneva;">Thanks &amp; Regards,</span></p>
<p><span style="font-size: 10pt; font-family: verdana, geneva;">MTIS-Applications And Platform Support | DAP Operation Team</span></p>
"""  %(FIRST_NAME, secret_keys, access_keys)

  # The character encoding for the email.
  CHARSET = "UTF-8"
  session = boto3.Session(profile_name='dev')
  # Create a new SES resource and specify a region.
  client = session.client('ses')

  # Try to send the email.
  try:
    #Provide the contents of the email.
    response = client.send_email(
        Destination={
            'ToAddresses': [
                 iam_user,
            ],
            'BccAddresses': [
                'DAPOnsiteOffshore@hbo.com',
            ],
        },
        Message={
            'Body': {
                'Html': {
                    'Charset': CHARSET,
                    'Data': BODY_HTML,
                },
            },
            'Subject': {
                'Charset': CHARSET,
                'Data': SUBJECT,
            },
        },
        Source='DAPOperationsSupport@hbo.com',
    )

  # Display an error if something goes wrong.
  except ClientError as e:
    logger.error("An error occured while sending email to user '{}'. Error Response: {}".format(iam_user, e.response['Error']['Message']))
  else:
    logger.debug("Email with access keys sent to the user '{}'! Message ID: {}".format(iam_user, response['MessageId']))


def main():
  """
  Main function
  """
  init_logger()
  options=args_parse()
  users=[x.strip() for x in options.iam_users.split(',')]
  for email_id in users:
           create_user(email_id)
           logger.debug("****************************************************************************************************************")
           logger.debug("****************************************************************************************************************")

if __name__ == '__main__':
       main()

sys.exit()
