#!/usr/bin/python
#### Script to create new policy and assign it to a role

import os
import sys
import json
import boto3


# Input argument parser
bucket_name=sys.argv[1]
stage_name=sys.argv[2]
env=sys.argv[3]
role_name=sys.argv[4]

# Create IAM client
session = boto3.Session(profile_name=env)
iam = session.client('iam')

# Create a policy
managed_policy = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "VisualEditor0",
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:GetObjectVersion",
                "s3:PutObject"
            ],
            "Resource": [
                "arn:aws:s3:::{}/*".format(bucket_name)
            ]
        },
        {
            "Sid": "VisualEditor1",
            "Effect": "Allow",
            "Action": "s3:List*",
            "Resource": [
            	"arn:aws:s3:::{}".format(bucket_name)
	    ],
            "Condition": {
                "StringLike": {
                    "s3:prefix": "*"
                }
            }
        }
    ]
}

#Create a policy
try:
 response = iam.create_policy(
    	PolicyName=stage_name,
    	PolicyDocument=json.dumps(managed_policy)
 )
 print(response)
 ARN=response['Policy']['Arn']
 create_iam_policy=response['ResponseMetadata']['HTTPStatusCode']
 if (create_iam_policy==200):
        print("Policy has been created %s\n") %(response)
 else:
        print("Unable to create the policy %s\n") %(response)
except:
  print("Unable to create a new policy, trying to attach the exisiting policy to the role!")
  if (env=="prod"):
      ARN="arn:aws:iam::506334935535:policy/{}".format(stage_name)
  else:
      ARN="arn:aws:iam::613630599026:policy/{}".format(stage_name)

# Attach a role policy
try:
 attach_policy=iam.attach_role_policy(
    	PolicyArn=ARN,
    	RoleName=role_name
 )
 attach_role=attach_policy['ResponseMetadata']['HTTPStatusCode']
 if (attach_role==200):
	print("Policy has been assigned to the role %s %s\n") %(role_name, attach_policy) 
 else:
	print("Unable to attach the policy to the role %s %s\n") %(role_name, attach_policy)
except:
        print("Unable to attach new policy to the role!\n")
