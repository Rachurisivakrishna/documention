#!/usr/bin/python

####Python script to send email using SES####

import sys
import boto3
from botocore.exceptions import ClientError


SENDER = "DAPOperationsSupport@hbo.com"
RECIPIENT = sys.argv[1]
DLRECIPIENT = "DAPOnsiteOffshore@hbo.com"
NAME = sys.argv[2]
PASSWORD= sys.argv[3]
WAREHOUSE = sys.argv[4]
ROLE =  sys.argv[5]
CNAME=NAME.capitalize()

# The subject line for the email.
SUBJECT = "Snowflake Credentials"

# The HTML body of the email.
BODY_HTML = """<p><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">Hi %s,</span></p>
<p><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">&nbsp; &nbsp; Snowflake login has been&nbsp;created as per the request. Please find the login details below.</span></p>
<p><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">&nbsp; &nbsp; &nbsp; <strong><span style="font-family: 'Verdana',sans-serif;">Login Name: %s</span></strong></span></p>
<p><strong><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">&nbsp; &nbsp; &nbsp; Login Password: %s</span></strong></p>
<p><strong><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">&nbsp; &nbsp; &nbsp; Warehouse: %s</span></strong></p>
<p><strong><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">&nbsp; &nbsp; &nbsp; Role : %s</span></strong></p>
<p><strong><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">&nbsp; &nbsp; &nbsp; SnowFlake URL:</span><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;"> <a href="https://urldefense.proofpoint.com/v2/url?u=https-3A__wc05407.us-2Deast-2D1.snowflakecomputing.com&amp;d=DwMCaQ&amp;c=w1ov7hFdLVrlh6z18-DI5A&amp;r=8syDVe-BEy5kPC3-DG5jzVSUZjPxu4HIk1UZMMnUoFE&amp;m=cwPtzZDfieFuMaYAigmcajj6Y0Hx0uMbEyWYSMuJo-8&amp;s=b_iVD8Cf9hkBA3TPrkDcYtqGxXt-wYYm2ao1gePkOHU&amp;e=">https://wc05407.us-east-1.snowflakecomputing.com</a></span></strong></p>
<p><strong><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">&nbsp; &nbsp; &nbsp; Okta_URL: <a href="https://hbo.okta.com/home/snowflake/0oa1gq83v57ag7SGp0h8/54889">https://hbo.okta.com/home/snowflake/0oa1gq83v57ag7SGp0h8/54889</a></span></strong></p>
<p>&nbsp;</p>
<p><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">Thanks &amp; Regards,</span><br /><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">MTIS-Applications And Platform Support | DAP Operations Team</span></p>"""  %(CNAME,RECIPIENT,PASSWORD,WAREHOUSE,ROLE)

# The character encoding for the email.
CHARSET = "UTF-8"

# Create a new SES resource and specify a region.
client = boto3.client('ses',region_name="us-east-1")

# Try to send the email.
try:
    #Provide the contents of the email.
    response = client.send_email(
        Destination={
            'ToAddresses': [
                RECIPIENT,
            ],
            'BccAddresses': [
                DLRECIPIENT,
            ],
        },
        Message={
            'Body': {
                'Html': {
                    'Charset': CHARSET,
                    'Data': BODY_HTML,
                },
            },
            'Subject': {
                'Charset': CHARSET,
                'Data': SUBJECT,
            },
        },
        Source=SENDER,
    )

# Display an error if something goes wrong.	
except ClientError as e:
    print(e.response['Error']['Message'])
else:
    print("Email sent! Message ID:"),
    print(response['MessageId'])


sys.exit()
