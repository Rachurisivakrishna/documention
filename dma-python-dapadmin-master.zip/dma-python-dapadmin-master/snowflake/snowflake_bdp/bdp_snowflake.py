#!/usr/bin/python

##########################################################
#'''Automation for Snowflake CI/CD Jenkins deployments'''#
##########################################################

import re
import os
import sys
import glob
import time
import boto3
import sqlparse
import logging
import datetime
import optparse
import snowflake.connector


def args_parse():
       """                     
       Argument parser function to receive all input variables
       """
       parser = optparse.OptionParser()
       parser.add_option('-b', '--build_path', action="store", dest="build_path", help="query string", default="")
       parser.add_option("-w", "--workspace_path", action="store", dest="workspace_path", help="query string", default="")
       parser.add_option("-e", "--env", action="store", dest="env", help="query string", default="")
       parser.add_option("-g", "--grant_file", action="store", dest="grant_file", help="query string", default="")
       parser.add_option("-s", "--sfuser", action="store", dest="sf_user", help="query string", default="")
       parser.add_option("-p", "--sfpwd", action="store", dest="sf_pwd", help="query string", default="")
       parser.add_option("-l", "--warehouse", action="store", dest="warehouse", help="query string", default="") 
       options, args = parser.parse_args()
       return options


def init_logger():
       """
       Initializing logger function for effective logging of Snowflake deployment
       """
       global logger
       logger = logging.getLogger('SF')
       logger.setLevel(logging.DEBUG)
       ch = logging.StreamHandler()
       ch.setLevel(logging.DEBUG)
       formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
       ch.setFormatter(formatter)
       logger.addHandler(ch)
       return logger

def connect(db_name, schema_name, warehouse_name, role_name, sf_user, sf_pwd):
       """
       Connect to snowflake using snowflake.connector, Main funcion
       to enable snowflake connection
       """
       conn = snowflake.connector.connect(
           user = sf_user,
           password = sf_pwd,
           account = "wc05407.us-east-1.privatelink",
           autocommit = True
       )
       try:
         # Running queries
         cur = conn.cursor()
         cur.execute("alter session set timezone = 'UTC';")
         cur.execute("use role {}".format(role_name))
         logger.debug("Using Role: {}".format(role_name))
         cur.execute("use database {}".format(db_name))
         logger.debug("Using Database: {}".format(db_name)) 
         if schema_name:
            cur.execute("use schema {}".format(schema_name))
            logger.debug("Using Schema: {}".format(schema_name))
         cur.execute("use warehouse {}".format(warehouse_name))
       except snowflake.connector.errors.ProgrammingError as e:
         logger.error(e)
         logger.error('Error {0} ({1}): {2} ({3})'.format(e.errno, e.sqlstate, e.msg, e.sfqid))
       finally:
         cur.close()

       return conn

       
def ddl_format():
       """
       Formats all ddl git checkout files, and parses the database, schema and
       table name from the query. Identifies create and alter statements and 
       makes corresponding function calls.
       """
       options=args_parse() 
       logger.debug("Formatting git checkout files!")
       build_dbfile = open(options.build_path, "r") ## Getting db name, schema name and table name from query. ## 
       if os.stat(options.build_path).st_size > 0:
        logger.debug("******Begin executing DDL from dma-dw-elt Github repo******")
        for line in build_dbfile:  ## Build path databases file contains path and file name. ##
          logger.debug("Executing sql query from database file.")
          if ("ddl/" in line):  ## Checks if it is a create query. ##
              logger.debug("*****Found create statement, proceeding for execution.")
              directory_path, file_name = os.path.split(line)
              file_path=(options.workspace_path+line).strip()
              db_name, schema_name, table_name=yield_db_vars_ddl(file_path, line)
              query=file_format(file_path) ## Section read the queries from file for cursor execution. ##
              logger.debug("Execution for File Name: {}".format(file_path))
              if (options.env=="dev"):
                  logger.debug("Executing ddl create in Dev environment.!")
                  conn = connect(db_name+'_dev', schema_name, options.warehouse, "ACCOUNTADMIN", options.sf_user, options.sf_pwd)
                  execute_ddl('_dev', conn, query, db_name+'_dev', schema_name)
              elif (options.env=="beta"):
                  logger.debug("Executing ddl create in Beta environment.!")
                  conn = connect(db_name+"_beta", schema_name, options.warehouse, "ACCOUNTADMIN", options.sf_user, options.sf_pwd)
                  execute_ddl('_beta', conn, query, db_name+'_beta', schema_name)
              else:
                  logger.debug("Executing ddl create in Prod environment.!")
                  conn = connect(db_name+"_prod", schema_name, options.warehouse, "ACCOUNTADMIN", options.sf_user, options.sf_pwd)
                  execute_ddl('_prod', conn, query, db_name+'_prod', schema_name)

          elif ('/release' in line): ## Checks if it is release folder. ##
              logger.debug("*****Found alter statement, proceeding for execution.")
              file_path=(options.workspace_path+line).strip()
              logger.debug("Execution for all alter statements under {}".format(file_path))
              if (options.env=="dev"):
                  logger.debug("Executing ddl create in Dev environment.!")
                  execute_release("dev", line.strip(), options.workspace_path)

              elif (options.env=="beta"):
                  logger.debug("Executing ddl create in Beta environment.!")
                  execute_release("beta", line.strip(), options.workspace_path)

              else:
                  logger.debug("Executing ddl create in Prod environment.!")
                  execute_release("prod", line.strip(), options.workspace_path)  
       else:
          logger.error("****************************************************\n")
          logger.error("No Database files found for deployment, aborting....\n")
          logger.error("****************************************************\n")
          os.system("echo 'NO DB FILE FOUND' > {}".format(options.build_path))
          sys.exit(1)

def yield_db_vars_ddl(file_path, line):
       """
       Parsing db name, schema name and table name from file path for ddl
       """
       schema_name=os.path.basename(os.path.dirname(line))
       database_name=re.search('src/sql/hbo/(.*)/ddl/*', line)
       db_name=(database_name.group(1))
       table_name=''
       return db_name, schema_name, table_name

def yield_db_vars_alter(file_path):
       """
       Getting db name, schema name and table name from file for alter statements
       """
       database_name=re.search('src/sql/hbo/(.*)/release/*', file_path)
       with open(file_path) as ddl_file: ## Open sql files for parsing db, schema & table name. ##
         for lines in ddl_file:
           s = lines.lower().split()
           for i,j in enumerate(s):
            if ("." in j):
               schema_name,table_name=j.split('.')
               return database_name.group(1), schema_name, table_name
       ddl_file.close()

def execute_release(env, file_path, workspace_path):
       """
       Execute alter files from DAP-*** directory.
       """
       options=args_parse()
       rfile_path=(workspace_path+file_path)
       count = 0
       sorted_files=sorted(os.listdir(rfile_path))
       try:
         for filename in sorted_files:
           if filename.endswith(".sql"):
              sql_file=(rfile_path+'/'+filename)
              logger.debug("Begin processing file: {}".format(sql_file))
              query=file_format(sql_file) #     file2statements(sql_file)
              db_name, schema_name, table_name= yield_db_vars_alter(rfile_path+'/'+filename)
              logger.debug("Executing alter statements: {}".format(query))
              database_name=(db_name+'_'+env)
              teamid=db_name
              conn = connect(database_name, schema_name, options.warehouse, "ACCOUNTADMIN", options.sf_user, options.sf_pwd)
              cur = conn.cursor()
              results = cur.execute(query).fetchall()
              logger.debug("Alter statement results {}".format(results))
              count +=1
              if(count==(len(sorted_files))):
                logger.debug("Running get ddl statement!")
                getquery="select get_ddl('table', '{}')".format(table_name)
                op = cur.execute(getquery).fetchall()
                logger.debug("Get DDL statement results {}".format(op))
                if("create or replace" in op[0][0]):
                  update_create_ddl(env, options.workspace_path, teamid, schema_name, table_name, op[0][0], getquery)
                if("executed successfully" in results[0][0]):
                  alter_results.append(query)
                  alter_results.append(results[0][0]) 
       except snowflake.connector.errors.ProgrammingError as e:
              error_results.append(e)
              logger.error('******An exception occured while executing get_ddl statement to the table : {}'.format(e))
              logger.error('Error {0} ({1}): {2} ({3})'.format(e.errno, e.sqlstate, e.msg, e.sfqid))

       finally:
              cur.close()

def update_create_ddl(env, workspace_path, teamid, schema_name, table_name, sf_getddl_query, exe_ddl_query):
       """
       After altering the table, update the old sql file with the updated ddl and append the output ddl to list.
       """
       getddl_results.append(exe_ddl_query)
       getddl_results.append(sf_getddl_query)
       if(env=="beta"):
         table_name=table_name.upper()
         append_file=(workspace_path+'src/sql/hbo/'+teamid+'/ddl/tables/'+schema_name+'/'+table_name+'.sql')
         logger.debug("Append old file '{}.sql' from file path {}. with the updated sql from Snowflake.".format(table_name, append_file))
         with open(append_file, 'r+') as inTF, open('/tmp/dont_delete.sql', 'w') as ouTF:
          for line in inTF:
            ouTF.write(line)
            if '***/' in line:
                break
          ouTF.write(sf_getddl_query)
          ouTF.close()
          inTF.close()
         os.system('cat /tmp/dont_delete.sql > {}'.format(append_file))


def execute_ddl(env, conn, query, db_name, schema):
       """
       Run create and grant statments on Snowflake
       """  
      
       options=args_parse()
       teamid=db_name.replace(env,"")
       try:
         logger.debug("Begin executing create statements: {}".format(query))
         cur = conn.cursor()
         results = cur.execute("""{}""".format(query.replace("\n", " "))).fetchall()
         if("successfully created" in results[0][0]):
           exe_results.append(query)
           exe_results.append(results[0][0])
           logger.debug("Table has been created successfully.")
           if("Sequence" in results[0][0]):
               seq_ca="GRANT USAGE  ON ALL SEQUENCES IN SCHEMA DW TO COMMON_ANALYTICS"
               seq_etl="GRANT ALL PRIVILEGES  ON ALL SEQUENCES IN SCHEMA staging TO COMMON_ETL"
               cur.execute(seq_ca)
               cur.execute(seq_etl)
               grant_results.append(seq_ca)
               grant_results.append(seq_etl) 
           elif("Function" in results[0][0]):
               fun_ca="GRANT USAGE  ON ALL FUNCTIONS IN SCHEMA DW TO COMMON_ANALYTICS"
               fun_etl="GRANT ALL PRIVILEGES  ON ALL FUNCTIONS IN SCHEMA staging TO COMMON_ETL"  
               cur.execute(fun_ca)
               cur.execute(fun_etl)
               grant_results.append(fun_ca)
               grant_results.append(fun_etl)
           else:
             for s in file_format_multiple_sql(options.grant_file):
               db_re=s.replace("{db_name}", db_name)
               sc_re=db_re.replace("{schema_name}", schema)
               grant_query=sc_re.replace("{db_prefix}", teamid)
               grant_op = cur.execute(grant_query).fetchall()
               if(schema=="staging" and env=="beta"): # or (schema=="dw"):
                   cur.execute("GRANT SELECT  ON ALL TABLES IN SCHEMA {}.{} TO ROLE {}_READ".format(db_name, schema, teamid))
               if("executed successfully" in grant_op[0][0]):
                   logger.debug("Granted permissions to the table: {}".format(grant_query))
                   grant_results.append(grant_query)
                   grant_results.append(grant_op[0][0])
               else:
                   logger.error("Unable to provide grant permissions to the Table name")
         else:
           logger.error("Unable to create the Table name")
           logger.debug("DDL create statement results: {}".format(results))
         
         return results

       except snowflake.connector.errors.ProgrammingError as e:
         logger.error('******An exception occured while processing create/grant statement to the table : {}'.format(e))
         logger.error('Error {0} ({1}): {2} ({3})'.format(e.errno, e.sqlstate, e.msg, e.sfqid))

       finally:
         cur.close()



def file_format(filename):
       """
       Formats & Remove comments from the entire sql file and split multiple sql statements
       """
       open_file = open(filename,'r')
       file_data=open_file.read()
       sql_file=file_data.lower()
       file_parse=sqlparse.format(sql_file, strip_comments=True).strip()
       statements=list(file_parse)
       statements=[x for x in statements if x]
       statements="".join(statements)
       return statements
    

def file_format_multiple_sql(filename):
       """
       Formats & Remove comments from the entire sql file.
       """
       open_file = open(filename,'r')
       file_data=open_file.read()
       sql_file=file_data.lower()
       file_parse=sqlparse.format(sql_file, strip_comments=True).strip()
       statements=file_parse.split(";")
       statements=[x.strip(' ') for x in statements]
       statements=[x for x in statements if x]
       return statements



exe_results=[]
getddl_results=[]
grant_results=[]
alter_results=[]
error_results=[]

def summary_handler():
       """
       Append results into lists
       """
       print('/n')
       print("*"*50+"BUILD SUMMARY"+"*"*50)
       print("-"*52+'\n')
       if (exe_results):
          print("**Table Creation Results**")
          print("-"*27)
          for i in exe_results: print(i)
          print("-"*52+'\n')

       if (grant_results):
          print("**Grant Permission Results**")
          print("-"*28)
          for j in grant_results: print(j)
          print("-"*52+'\n')

       if (alter_results):
          print("**Alter Execution Results**")
          print("-"*28)
          for k in alter_results: print(k)
          print("-"*52+'\n')

       if (getddl_results):
          print("**Get DDL Execution Results**")
          print("-"*28)
          for m in getddl_results: print(m)
          print("-"*52+'\n')

       if (error_results):
          print("**Error Execution Results**")
          print("-"*28)
          logging.error("*"*50+"BUILD FAILED"+"*"*50)
          for l in error_results: print(l)
          print("-"*52+'\n')
       print("-"*52+'\n')


def main():
       init_logger()
       args_parse()
       ddl_format()
       summary_handler()

if __name__ == '__main__':
       main()

sys.exit()


