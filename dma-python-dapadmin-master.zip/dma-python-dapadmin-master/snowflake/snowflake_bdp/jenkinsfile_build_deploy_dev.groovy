def WORKSPACE = "${JENKINS_HOME}/workspace/${JOB_NAME}/${BUILD_NUMBER}"
def db = "${JENKINS_HOME}/workspace/${JOB_NAME}/${BUILD_NUMBER}/databases"

pipeline {
    agent any
    environment {
        GIT_REPO = 'git@github.com:HBOCodeLabs/dma-dw-elt.git'
        GIT_REPO_PY = 'git@github.com:HBOCodeLabs/dma-python-dapadmin.git'
        CREDENTIALSID = '4d39b737-9c62-4a5f-95f4-c4589b9ac981'
    }
    stages {
        stage('Git Checkout') {
            steps {
                //sh "echo '******Commit ID : `cat ${JENKINS_HOME}/workspace/${JOB_NAME}/commit_id2`******"
                sh "rm -rf dma-python-dapadmin src dma-dw-elt"
                sh(script: "mkdir -p ${WORKSPACE}")
                sh "git clone -b snowflake-dma-integrationdev ${GIT_REPO}"
                sh "cp -r dma-dw-elt/* . && rm -rf dma-dw-elt"
                sh "cp ${JENKINS_HOME}/workspace/${JOB_NAME}/commit_id ${JENKINS_HOME}/workspace/${JOB_NAME}/${BUILD_NUMBER}/"
                sh "cp ${JENKINS_HOME}/workspace/${JOB_NAME}/commit_id2 ${JENKINS_HOME}/workspace/${JOB_NAME}/${BUILD_NUMBER}/"
                sh "git diff --diff-filter=ACMR --name-only `cat ${JENKINS_HOME}/workspace/${JOB_NAME}/${BUILD_NUMBER}/commit_id` `cat ${JENKINS_HOME}/workspace/${JOB_NAME}/${BUILD_NUMBER}/commit_id2` | grep -iE 'src/sql/hbo/.*/ddl/.*.sql' | grep -v '/tables/grants_' | grep -v 'DAP' |sort -u > ${JENKINS_HOME}/workspace/${JOB_NAME}/${BUILD_NUMBER}/databases"
                sh '''git diff --diff-filter=ACMR --name-only `cat ${JENKINS_HOME}/workspace/${JOB_NAME}/${BUILD_NUMBER}/commit_id` `cat ${JENKINS_HOME}/workspace/${JOB_NAME}/${BUILD_NUMBER}/commit_id2` | grep -i "DAP-" | sed "s,/*[^/]*$,," | sort -u >> ${JENKINS_HOME}/workspace/${JOB_NAME}/${BUILD_NUMBER}/databases'''
                dir('dma-python-dapadmin') {
                 checkout(
                    poll:false,
                    changelog:false,
                    scm: [
                        $class:'GitSCM',
                        branches: [[name:'nidhin']],
                        clean:true,
                        extensions: [[$class: 'DisableRemotePoll'],
                        [$class: 'PathRestriction', excludedRegions: '*']], 
                        userRemoteConfigs: [[url: 'git@github.com:HBOCodeLabs/dma-python-dapadmin.git']],
                        credentialsId: "${CREDENTIALSID}",
                    ]) 
                    } 
               }
            }
         stage('Building into Dev Environment') {
            steps {
             withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'snowflake', usernameVariable: 'SFUSERNAME', passwordVariable: 'SFPASSWORD']]) { 
                sh 'echo "******Deploying code to Dev Environment******"'
                //sh 'python ./dma-python-dapadmin/snowflake/snowflake_bdp/bdp_snowflake.py -b ${JENKINS_HOME}/workspace/${JOB_NAME}/${BUILD_NUMBER}/databases -w ${JENKINS_HOME}/workspace/${JOB_NAME}/ -e dev -g ${JENKINS_HOME}/workspace/${JOB_NAME}/src/sql/grants/grant_dev.sql -s ${SFUSERNAME} -p ${SFPASSWORD} -l WH_SF_ADMIN'
            }
          }
        }
        stage('Building into Beta Environment') {
            steps {
             withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'snowflake', usernameVariable: 'SFUSERNAME', passwordVariable: 'SFPASSWORD']]) { 
                sh 'echo "******Deploying code to Beta Environment******"'
                sh 'python ./dma-python-dapadmin/snowflake/snowflake_bdp/bdp_snowflake.py -b ${JENKINS_HOME}/workspace/${JOB_NAME}/${BUILD_NUMBER}/databases -w ${JENKINS_HOME}/workspace/${JOB_NAME}/ -e beta -g ${JENKINS_HOME}/workspace/${JOB_NAME}/src/sql/grants/grant_beta_prod.sql -s ${SFUSERNAME} -p ${SFPASSWORD} -l WH_SF_ADMIN'
            }
            }
        }
      }
      
    post {
        always { 
            script {
                withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'jenkinsbdp', usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) { 
                  sh "curl -o logs/snowflakebdp_${BUILD_NUMBER}.log  -u $USERNAME:$PASSWORD http://10.69.1.164:8080/job/${env.JOB_NAME}/${env.BUILD_NUMBER}/consoleText"
                  sh 'cat ${JENKINS_HOME}/workspace/${JOB_NAME}/commit_id2 > ${JENKINS_HOME}/workspace/${JOB_NAME}/commit_id'
                  //sh 'git rev-parse HEAD > ${JENKINS_HOME}/workspace/${JOB_NAME}/commit_id'
                  sh 'aws s3 sync logs/ s3://hbo-jenkins-buildlogs-dev/snowflake/logs/ --sse AES256'
                  databases = sh returnStdout: true, script: '''cat ${JENKINS_HOME}/workspace/${JOB_NAME}/${BUILD_NUMBER}/databases | awk "{print}" ORS=" "'''
                  //sh 'bash ./dma-python-dapadmin/snowflake/snowflake_bdp/cleanup_local_remote_branches.sh'
                  sh 'cp /opt/jenkins/common_scripts/cleanup_integration_branches.sh .'
                  sh 'bash ./cleanup_integration_branches.sh'
                  result = readFile(db).trim()
                  res = result.replaceAll("\n", ", \n")
                  manager.addInfoBadge("DEPLOY")
                  manager.addShortText("${res}", "black", "white", "2px", "green")
                  summary = manager.createSummary("gear2.gif")
                  summary.appendText("<h3>${res}</h3>", false, false, false, "green")
         }
                
            }
        }
        success {
            script {
             if (currentBuild.currentResult == "SUCCESS")
             {
                 databases = sh returnStdout: true, script: '''cat ${JENKINS_HOME}/workspace/${JOB_NAME}/${BUILD_NUMBER}/databases | awk "{print}" ORS=" "'''
                 commit_user = sh returnStdout: true, script: '''git log -1 --pretty=format:"%an"'''
                 try {
                    sh "echo 'Database File'"
                    sh "echo '**************'"
                    sh "echo $databases"
                    sh '''git add src/ && git commit -m "updated sql ddl" > /dev/null  2>&1 && git push -u origin snowflake-dma-integrationdev'''
                 } catch (Exception e) {
                    echo 'Nothing to commit'
                 }
                 try {
                    sh '''git branch -D snowflake-dma-integrationdev-"${BUILD_NUMBER}"'''
                 } catch (Exception e) {
                    echo 'No existing local branch named "snowflake-dma-integrationdev-${BUILD_NUMBER}" for deletion, proceeding to create new branch.'
                 }
                 sh '''git checkout -b snowflake-dma-integrationdev-${BUILD_NUMBER} && git push -u origin snowflake-dma-integrationdev-${BUILD_NUMBER} '''
                 pull_request = sh returnStdout: true, script: '''/usr/local/bin/hub pull-request -h HBOCodeLabs:snowflake-dma-integrationdev-${BUILD_NUMBER} -m "JENKINS AUTOMATED PR - SNOWFLAKE_BUILD_DEPLOY - ${BUILD_NUMBER}"'''
                 sh '''git checkout snowflake-dma-integrationdev'''
                 emailext (
                   subject: "PROD DEPLOY PR APPROVAL: JOB '${env.JOB_NAME} - [${env.BUILD_NUMBER}]'",
                   body: """<p><span style="font-size: 10pt; font-family: georgia, palatino;">Hello,</span></p>
<p><span style="font-size: 10pt; font-family: georgia, palatino;">A new pull request made by developer '${commit_user}' on Integration Branch is waiting for approval to merge with master.</span></p>
<p><strong><span style="font-size: 10pt; font-family: georgia, palatino;">Commited Databases: '${databases}'</span></strong></p>
<p><strong><span style="font-size: 10pt; font-family: georgia, palatino;">Pull Request URL: "<a href="${pull_request}">${pull_request}</a>"</span></strong></p>
<p><span style="font-size: 10pt; font-family: georgia, palatino;">Please review the build in Dev and Beta: "<a href="${env.BUILD_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</span></p>
<p>&nbsp;</p>
<p><span style="font-size: 10pt; font-family: georgia, palatino;"><strong>Note: This is an automated response, please send an email to <a href="mailto:DAPOperationsSupport@hbo.com">DAPOperationsSupport@hbo.com</a>&nbsp;for any queries.</strong></span></p>
<p><span style="font-size: 10pt; font-family: georgia, palatino;">Thanks &amp; Regards,</span><br /><span style="font-size: 10pt; font-family: georgia, palatino;">MTIS-Applications And Platform Support | DAP Operations Team</span></p>""",
                          to: 'nidhin.nairru@hbo.com',
                        )
                
             }

           }
        }
    }
    }

