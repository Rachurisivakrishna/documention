#!/bin/bash
set +x
rm commits
rm -rf ../DEV.SNOWFLAKE.BUILD.DEPLOY/src
SF_BPD_COMMIT_ID=$(cat $workspace../DEV.SNOWFLAKE.BUILD.DEPLOY/commit_id)
echo $SF_BPD_COMMIT_ID

time=$(cd $workspace../DEV.SNOWFLAKE.BUILD.DEPLOY/ && git show -s --format=%cD $SF_BPD_COMMIT_ID)
echo $time

#Pull remote origin "snowflake-dma-integrationdev"
pull=$(cd $workspace../DEV.SNOWFLAKE.BUILD.DEPLOY/ && git checkout snowflake-dma-integrationdev && git pull origin snowflake-dma-integrationdev)

#Get files changed
file_changed=$(cd $workspace../DEV.SNOWFLAKE.BUILD.DEPLOY/ && git log --pretty=format:"%H" --since="$time" | grep -v $SF_BPD_COMMIT_ID)
echo $file_changed | tr " " "\n" > commits

#Curl vars for jenkins
HTTPS_URL="http://10.69.1.20:8080/job/DEV.SNOWFLAKE.BUILD.DEPLOY/build?"
CURL_CMD="curl -I -X POST -w httpcode=%{http_code} -u $jenkins_user:$jenkins_pwd"
# -m, --max-time <seconds> FOR curl operation
CURL_MAX_CONNECTION_TIMEOUT="-m 100"
while read -r id || [ -n "$id" ]
do
  echo "$id"
  if [[ ! -z "$id" ]]; then
   echo "*****************************************************************************"
   echo "Commit ID found, copying Commit ID to 'DEV.SNOWFLAKE.BUILD.DEPLOY' workspace path"
   echo "*****************************************************************************"
   echo $id > $workspace../DEV.SNOWFLAKE.BUILD.DEPLOY/commit_id2
   file_db=$(cd $workspace../DEV.SNOWFLAKE.BUILD.DEPLOY/ && git diff --diff-filter=ACMR --name-only `cat ${JENKINS_HOME}/workspace/DEV.SNOWFLAKE.BUILD.DEPLOY/commit_id` `cat ${JENKINS_HOME}/workspace/DEV.SNOWFLAKE.BUILD.DEPLOY/commit_id2` | grep -iE 'src/sql/hbo/.*/ddl/.*.sql' | grep -v '/tables/grants_' | grep -v 'DAP' |sort -u > ${JENKINS_HOME}/workspace/DEV.SNOWFLAKE.BUILD.DEPLOY/databases)
   file_db=$(cd $workspace../DEV.SNOWFLAKE.BUILD.DEPLOY/ && git diff --diff-filter=ACMR --name-only `cat ${JENKINS_HOME}/workspace/DEV.SNOWFLAKE.BUILD.DEPLOY/commit_id` `cat ${JENKINS_HOME}/workspace/DEV.SNOWFLAKE.BUILD.DEPLOY/commit_id2` | grep -i "DAP-" | sed "s,/*[^/]*$,," | sort -u >> ${JENKINS_HOME}/workspace/DEV.SNOWFLAKE.BUILD.DEPLOY/databases)
   if [ -s "${JENKINS_HOME}/workspace/DEV.SNOWFLAKE.BUILD.DEPLOY/databases" ]; then
	CURL_RETURN_CODE=0
    CURL_OUTPUT=`${CURL_CMD} ${CURL_MAX_CONNECTION_TIMEOUT} ${HTTPS_URL} 2> /dev/null` || CURL_RETURN_CODE=$?
    sleep 12s
    if [ ${CURL_RETURN_CODE} -ne 0 ]; then  
	   echo "*************************************************************"
       echo "Curl connection failed with return code - ${CURL_RETURN_CODE}"
	   echo "*************************************************************"
    else
	   echo "***********************"
       echo "Curl connection success"
	   echo "***********************"
    # Check http code for curl operation/response in  CURL_OUTPUT
       httpCode=$(echo "${CURL_OUTPUT}" | sed -e 's/.*\httpcode=//')
       if [ "$httpCode" -ne 201 ]
       then
	    echo "*********************************************************************"
        echo "Curl operation/command failed due to server return code - ${httpCode}"
	 	echo "*********************************************************************"
		exit 1
	   else
	    echo "****************************************************************"
	    echo "Successfully triggered the remote build 'SNOWFLAKE_BUILD_DEPLOY'"
     	echo "****************************************************************"
       fi
    fi
   else
     echo "*********************************"
     echo "No DB Files found for deployment."
     echo "*********************************"
     sh 'cat $workspace/DEV.SNOWFLAKE.BUILD.DEPLOY/commit_id2 > $workspace/DEV.SNOWFLAKE.BUILD.DEPLOY/commit_id'
   fi
  else
   echo "************************************" 
   echo "No commit id found in Remote Origin!"
   echo "************************************"
   cd $workspace../DEV.SNOWFLAKE.BUILD.DEPLOY/ && git rev-parse HEAD > $workspace../DEV.SNOWFLAKE.BUILD.DEPLOY/commit_id
  fi

done < commits

