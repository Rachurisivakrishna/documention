#!/usr/bin/python

import os
import sys
import time
import string
import random
import logging
import snowflake.connector


LOGGER = logging.getLogger(__name__)

####Credentials initialization
def creds_init():

        creds_init.admin_user = os.environ["Admin_User"]
        creds_init.admin_password = os.environ["Admin_Pass"]
        creds_init.admin_account = "wc05407.us-east-1.privatelink"
        creds_init.email_id=os.environ["Email_ID"]
        creds_init.role=os.environ["Role"]
        creds_init.comment=os.environ["AD_Group"]
        creds_init.warehouse=os.environ["Warehouse"]
        creds_init.send_email=os.environ['Send_Email']
	creds_init.password_enforce = "FALSE"
        creds_init.account_type = os.environ["Service_Type"]


####Checking if snowflake configurations are valid####
def __init__():
        '''
        Intializes the connection object.
        Also performs validation on the params like USER,PWD and ACC.
        '''
        creds_init()

        param_validation_rule = [not creds_init.admin_user,
                                 not creds_init.admin_password,
                                 not creds_init.admin_account]

        if any(param_validation_rule):
            LOGGER.error('Missing Snowflake configuration')
            raise Exception('Missing Snowflake configuration')


####DB query initialization####
def connect_snowflake(query):
	
	start = time.time()
	creds_init()
	ctx = snowflake.connector.connect(
           		user=creds_init.admin_user,
           		password=creds_init.admin_password,
          		account=creds_init.admin_account,
	)
    	cs = ctx.cursor()
      	count = cs.execute(query)
        one_row = cs.fetchone()
	if (one_row is None):
             print("User does not exists, proceeding to create new user!")
	elif (one_row[0] == "User "+main.email_id+" successfully created."):
	     print(one_row[0])
	     print('\n')
	     if (creds_init.send_email == "yes"):
               if (creds_init.account_type == "Service_Account"):
		 os.system("AWS_PROFILE=dev python ./snowflake/sendemail.py "+main.email_id+" "+main.first_name+" "+pwd_gen.user+" "+creds_init.warehouse+" "+creds_init.role+"")
                 print('Login Name for new user: %s') %(main.email_id)
                 print('Login Password for new user: %s') %(pwd_gen.user)
               else:
                 os.system("AWS_PROFILE=dev python ./snowflake/sendemail.py "+main.email_id+" "+main.first_name+" Access_through_Okta-HBOLaunchPad "+creds_init.warehouse+" "+creds_init.role+"")
                 print('Login Name for new user: %s') %(main.email_id)
                 print('Login Password for new user: Access_through_Okta-HBOLaunchPad')
	elif (one_row[0] == "Statement executed successfully."):
	     print('\n')
             print(one_row[0])
             print('Role "%s" has been assigned to the user "%s"\n') %(creds_init.role,main.email_id)
	elif (one_row[23] is not None):
	     print(one_row)
	     print('\n')
             print('User %s already exists, Drop user and try creating again.\n') %(main.email_id)
             sys.exit(1)
	else:
    	     print "[SNOWFLAKE EXCEPTION] - UNABLE TO EXECUTE THE TASKS! - MANUAL INTERVENTION REQUIRED"
	cs.close()
      	ctx.close()
        return ctx

####Check if user already exists####
def user_exist():
    query_user="SHOW USERS like '%s'" %(main.email_id)
    connect_snowflake(query_user)

####Create user for snowflake####
def user_create():
    query_create='''CREATE USER "%s" PASSWORD = "%s" LOGIN_NAME = "%s" DISPLAY_NAME = "%s" FIRST_NAME = "%s" LAST_NAME = "%s" EMAIL = "%s" COMMENT= "%s" DEFAULT_NAMESPACE= "Workspace" DEFAULT_ROLE = "%s" MUST_CHANGE_PASSWORD = %s;''' %(main.email_id,pwd_gen.user,main.email_id,main.first_name,main.first_name,main.last_name,main.email_id,creds_init.comment,creds_init.role,creds_init.password_enforce)
    connect_snowflake(query_create)

####Grant Permission to the role####
def user_grant():
    query_grant='''GRANT ROLE "%s" TO USER "%s"''' %(creds_init.role,main.email_id)
    connect_snowflake(query_grant)

####Random password generator
def pwd_gen():
    if (creds_init.account_type=="Service_Account"):
        pwd_gen.user=''.join(random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for _ in range(16))
    else:
        pwd_gen.user=''

####Main function####
def main():
	__init__()
        creds_init()
        for email in creds_init.email_id.split(","):
                pwd_gen()
		main.email_id = email
                main.first_name=main.email_id.split(".")[0]
                try:
        	  main_last_name=main.email_id.split("@")[0]
        	  main.last_name=main_last_name.split(".")[1]
                except:
                  main.last_name=""
        	print('----------------------------------------------------------------------------------------------\n')
		user_exist()
		user_create()
		user_grant()
		print('----------------------------------------------------------------------------------------------\n')
		print('\n')


if __name__ == '__main__':
        LOGGER.info('Task completed successfully.!')
        creds_init()
        main()

sys.exit()
