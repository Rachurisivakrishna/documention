#!/usr/bin/python

import os
import sys
import time
import json
import uuid
import boto3
import logging
import optparse
import subprocess
import snowflake.connector
from subprocess import Popen, PIPE


'''
This script creates a new stage in Snowflake, grants the corresponding roles, gets the external id for stage and adds the external id to AWS trust policy!\n
'''

#### AWS connection ####
s3 = boto3.resource('s3')
client = boto3.client('s3')
iam_client = boto3.client('iam')


#### Credentials initialization ####
def login_init():

	 parser = optparse.OptionParser()
	 parser.add_option('-s', '--s3role', action="store", dest="s3_role", help="query string", default="")
	 parser.add_option('-e', '--env', action="store", dest="env", help="query string", default="")
	 parser.add_option('-b', '--bucket', action="store", dest="bucket", help="query string", default="")
	 options, args = parser.parse_args()
	 login_init.admin_user = os.environ['USERNAME']
	 login_init.admin_password = os.environ['PASSWORD']
	 login_init.admin_account = "wc05407.us-east-1.privatelink"
	 login_init.role = "ACCOUNTADMIN"
	 login_init.s3_bucket = options.bucket
	 login_init.s3_role = options.s3_role
	 login_init.env= options.env
         if (login_init.env == "prod"):
              s3_stage_name = login_init.s3_bucket.replace("-","_")
              login_init.s3_stage_name = s3_stage_name+"_prod"
         else:
              login_init.s3_stage_name = login_init.s3_bucket.replace("-","_")
	 login_init.stage_roles = os.environ['Roles']
	 login_init.database = os.environ['Database']
	 login_init.schema = os.environ['Schema']
	 login_init.role_name = os.environ['Role_Name']

#### Check if snowflake configurations are valid ####
def __init__():
        '''
        Intializes the connection object.
        Also performs validation on the params like USER,PWD and ACC.
        '''
        login_init()

        param_validation_rule = [not login_init.admin_user,
                                 not login_init.admin_password,
                                 not login_init.admin_account]

        if any(param_validation_rule):
            LOGGER.error('Missing Snowflake configuration')
            raise Exception('Missing Snowflake configuration')

#### DB query initialization ####
def connect_snowflake():
    	''' Inserts a timestamp into Snowflake DB '''
    	start = time.time()
    	__init__()
    	login_init()
    	ctx = snowflake.connector.connect(
        	user=login_init.admin_user,
        	password=login_init.admin_password,
        	account=login_init.admin_account,
		database=login_init.database,
		role=login_init.role,
		warehouse="MARKETING_ANALYTICS_DEVBETA",
		schema=main.schema_name
   	)
    	connect_snowflake.cs = ctx.cursor()

#### New stage creation ####
def new_stage():
	connect_snowflake()
	s3_url="""s3://{}/""".format(login_init.s3_bucket)
	query_stage = """CREATE OR REPLACE STAGE {}
         	     	 URL = '{}'
           	     	 CREDENTIALS = (AWS_ROLE = '{}')
             	     	 ENCRYPTION=(type='AWS_SSE_S3')""".format(login_init.s3_stage_name, s3_url, login_init.s3_role)
    	connect_snowflake.cs.execute(query_stage)
	one_row = connect_snowflake.cs.fetchone()
        logger.debug(str(one_row[0]))
	print ("\n")
	show_roles()

#### Getting all available roles in snowflakee ####
def show_roles():
        connect_snowflake()
        show_roles.result = [x.strip() for x in login_init.stage_roles.split(',')]
        grant_stage()

#### Grant permission to stage ####
def grant_stage():
	connect_snowflake()
	for roles in show_roles.result:
		query_grant = """GRANT USAGE ON STAGE {} to {}""".format(login_init.s3_stage_name, roles)
		connect_snowflake.cs.execute(query_grant)
		one_row = connect_snowflake.cs.fetchone()
		if (str(one_row[0]) == "Statement executed successfully."):
			logger.debug("Access has been granted to the stage '{}' with the role '{}'\n".format(login_init.s3_stage_name, roles))
	desc_stage()

#### Desc stage and get External ID ####
def desc_stage():
	connect_snowflake()
	connect_snowflake.cs.execute("USE WAREHOUSE {warehouse}".format(warehouse='MARKETING_ANALYTICS_DEVBETA'))
        query_desc = """desc stage {}""".format(login_init.s3_stage_name)
        connect_snowflake.cs.execute(query_desc)
        query_extid = """select "property_value" from table(result_scan(last_query_id())) where "property" = 'AWS_EXTERNAL_ID'"""
        connect_snowflake.cs.execute(query_extid)
	one_row = connect_snowflake.cs.fetchall()
        for eid in one_row[0]:
	     desc_stage.edi=eid
	logger.debug("Getting external id for s3 bucket {}\n".format(login_init.s3_bucket))
	logger.debug("AWS_EXTERNAL_ID: {}\n".format(desc_stage.edi))
	connect_snowflake.cs.close()

def get_iam_trust_policy():
       response = iam_client.get_role(
    			RoleName= login_init.role_name
			)

       policy=(response['Role']['AssumeRolePolicyDocument'])
       logger.debug("Getting IAM trust relationship policy {}\n".format(policy))
       with open('./snowflake/tasks/file_{}.json'.format(login_init.env), 'w') as outfile:
                     json.dump(policy, outfile, sort_keys = False, indent = 4, ensure_ascii = False)

#### Updating trust policy file with latest external ID ####
def aws_trust_policy():
	inputfile = open('./snowflake/tasks/file_{}.json'.format(login_init.env), 'r').readlines()
	write_file = open('./snowflake/tasks/file_{}.json'.format(login_init.env),'w')
        logger.debug("Updating trust policy file with External ID")
	for line in inputfile:
    		write_file.write(line)
    		if '"sts:ExternalId": [' in line:
            		item='"%s",' %(desc_stage.edi)
            		new_line = "\t\t%s" %(item)
            		write_file.write(new_line + "\n")
	write_file.close()
	aws_update_policy()

#### Updating trust policy in AWS IAM ####
def aws_update_policy():
	policyDoc = open('./snowflake/tasks/file_{}.json'.format(login_init.env), "r").read()
	response = iam_client.update_assume_role_policy(
   			 PolicyDocument=policyDoc,
    			 RoleName=login_init.role_name,
	)
	status_code=response['ResponseMetadata']['HTTPStatusCode']
	if (status_code == 200):
		logger.debug("Trusted policy has been successfully updated and external id has been added: {}\n".format(response))
	else:
		logger.error("******Unable to add trust policy to AWS role. {}!!\n".format(response))
		sys.exit(1)
	aws_create_iam()

#### Calling iam policy module ####
def aws_create_iam():
	process = Popen(['python', './snowflake/create_policy.py', login_init.s3_bucket, login_init.s3_stage_name, login_init.env, login_init.role_name], stdout=PIPE, stderr=PIPE)
	stdout, stderr = process.communicate()
        result = stdout.decode()
        if result:
           logger.debug('{}\n'.format(result))
        else:
           logger.error('{}\n'.format(stderr))
	aws_s3_folder_creation()

#### Object creation for s3 validation ####
def aws_s3_folder_creation():
	response = client.put_object(
        	Bucket=login_init.s3_bucket,
        	Body='',
		ServerSideEncryption='AES256',
        	Key='test-folder-admin/'
        )
	aws_s3_put_data()
        status_code=response['ResponseMetadata']['HTTPStatusCode']
        if(status_code==200):
                  logger.debug("Created test object for stage validation: {}.\n".format(response))
        else:
   		  logger.error("Unable to create a test object for stage validation: {}.\n".format(response))

#### Uploading test data to s3 bucket ####
def aws_s3_put_data():
	i=s3.meta.client.upload_file('./snowflake/tasks/test-file.json', login_init.s3_bucket, 'test-folder-admin/test-file.json', ExtraArgs={'ServerSideEncryption': 'AES256'})
        logger.debug("Uploading test data to S3 bucket for validation\n")

#### Validation step for stage Creation ####
def validate_stage():
	connect_snowflake()
        query_validate = """ls @{}/test-folder-admin;""".format(login_init.s3_stage_name)
	try: 
		connect_snowflake.cs.execute(query_validate)
        	one_row = connect_snowflake.cs.fetchone()
		s3_url="""s3://{}/test-folder-admin/test-file.json""".format(login_init.s3_bucket)
		if (one_row[0]==s3_url):
			logger.debug("Stage has been successfully validated {}".format(str(one_row[0])))
			aws_s3_delete()
		else:
		        logger.error("******Exception - Unable to validate new stage - Manual Intervention needed!")
			aws_s3_delete()
			sys.exit(1)
	except Exception as e: 
    		logger.error("******An exception occured while validating the stage: {}\n".format(str(e)))
                aws_s3_delete()
		sys.exit(1)

#### Deleting test folder function ####
def aws_s3_delete():
	bucket = s3.Bucket(login_init.s3_bucket)
        del_obj=bucket.objects.filter(Prefix="test-folder-admin").delete()
        logger.debug('Test file has been deleted from S3 bucket: {}'.format(str(del_obj)))


#Initializing logger for debug
def init_logger():
       global logger
       logger = logging.getLogger('*Stage_Creation*')
       logger.setLevel(logging.DEBUG)
       ch = logging.StreamHandler()
       ch.setLevel(logging.DEBUG)
       formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
       ch.setFormatter(formatter)
       logger.addHandler(ch)
       return logger

#### Main function ####
def main():
    print('********************************************************************************************************************')
    schema_in = [x.strip() for x in login_init.schema.split(',')]
    for main.schema_name in schema_in:
        __init__()
        login_init()
        logger.debug("***************** Creating stage '{}' in Database '{}' and using '{}' Schema! *****************\n\n".format(login_init.s3_stage_name, login_init.database, main.schema_name))
	new_stage()
        get_iam_trust_policy()
	aws_trust_policy()
	time.sleep(20)
	validate_stage()
	
if __name__ == '__main__':
        init_logger()
        login_init()
        main()

sys.exit()

