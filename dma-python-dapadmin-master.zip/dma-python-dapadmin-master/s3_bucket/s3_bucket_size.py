################################################################
######///////Script to get total size of S3 buckets///////######
################################################################

import os
import sys
import boto3
import botocore
from hurry.filesize import size

s3 = boto3.resource('s3')


##///Function to get the size of s3 bucket///##
def get_bucket_size(bucket_name):
     try:
        bucket = s3.Bucket(bucket_name)
        exists = True
        total_bytes = 0
        n = 0
        for k in bucket.objects.all():
                        total_bytes += k.size
                        n += 1
        total_size = size(total_bytes)
        print "S3_Bucket_Name: %s, Total Size: %s, Total No of Objects: %i"% (bucket_name, total_size, n)
     except:
        print "\n****Error**** Bucket with name '%s' not found in S3!****\n"% (bucket_name)


##//Main function to pass parameters and call get_bucket function//##
def main():
       buckets = os.environ['Bucket_name']
       s3_args = buckets.split(" ")
       for arg in s3_args:
                       s3_function = get_bucket_size(arg)


if __name__ == '__main__':
    main()

sys.exit()
