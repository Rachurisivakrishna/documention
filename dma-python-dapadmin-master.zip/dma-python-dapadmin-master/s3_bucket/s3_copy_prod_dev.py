#!/usr/bin/python3.4

'''Script to copy files from Prod to Dev S3 buckets in account'''

import os
import sys
import json
import time
import boto3
import logging
import subprocess
import datetime
from subprocess import Popen, PIPE
from botocore.exceptions import ClientError

src_bucket_name=os.environ['Prod_Bucket_Name']
src_key_path=os.environ['Prod_Key_Path']
dest_bucket_name=os.environ["Dev_Bucket_Name"]
dest_key_path=os.environ["Dev_Key_Path"]

#Get existing policy and update new bucket policy to the bucket
def get_update_policy(bucket_name):
  try:
     session = boto3.Session(profile_name='prod')
     client = session.client('s3')
     result = client.get_bucket_policy(Bucket=bucket_name)
     data=(result['Policy'])
     logger.debug("Getting existing policy from bucket and saving to a file. {}".format(data))
     formatjson=(json.loads(data))
     with open('./s3_bucket/template/old_policy.json', 'w') as outfile:
                          json.dump(formatjson, outfile, sort_keys = False, indent = 4, ensure_ascii = False)
     original_policy = open('./s3_bucket/template/old_policy.json', 'r').readlines()
     write_file = open('./s3_bucket/template/updated_policy.json','w')
     policy='''{
            	"Sid": "DAPAdmin-CrossAcountProd-Dev",
            	"Effect": "Allow",
            	"Principal": {
                	"AWS": "arn:aws:iam::613630599026:root"
            		},
            	"Action": [
                "s3:Get*",
                "s3:List*"
            		],
            	"Resource": [
                	"arn:aws:s3:::'''+bucket_name+'''/*",
                	"arn:aws:s3:::'''+bucket_name+'''"
            		]
        	}, '''
     for line in original_policy:
               write_file.write(line)
               if '"Statement": [' in line:
                        new_line = "\t\t\t\t%s" %(policy)
                        write_file.write(new_line + "\n")
     write_file.close()
     updated_policy = open('./s3_bucket/template/updated_policy.json', "r").read()
     logger.debug("Proceeding with updating the modified bucket policy to S3. Policy: {}".format(updated_policy))
     response = client.put_bucket_policy(
                        Bucket=bucket_name,
                        ConfirmRemoveSelfBucketAccess=False,
                        Policy=updated_policy
                   )
     status_code=response['ResponseMetadata']['HTTPStatusCode']
     if(status_code==204):
              logger.debug("Modified existing policy with cross account access has been updated in S3 bucket policy. Policy: {}".format(updated_policy))

  except ClientError as e:
     error_msg = (e.response['Error']['Message'])
     logger.debug('Unable to find an existing bucket policy. Error Message: "{}"'.format(error_msg))
     if (error_msg=="The bucket policy does not exist"):
        open('./s3_bucket/template/old_policy.json', 'w').close()
        logger.debug("Updating new bucket policy for bucket '{}'.\n".format(bucket_name))
        response = client.put_bucket_policy(
    	       		Bucket=bucket_name,
    	       		ConfirmRemoveSelfBucketAccess=False,
    	          	Policy='''{
    					"Version": "2012-10-17",
    					"Statement": [
        				   {
            					"Sid": "DAPAdmin-CrossAcountProd-Dev",
            					"Effect": "Allow",
            					"Principal": {
                				"AWS": "arn:aws:iam::613630599026:root"
            				   },
            				"Action": [
                				"s3:Get*",
                				"s3:List*"
            					],
            				"Resource": [
                				"arn:aws:s3:::'''+bucket_name+'''/*",
                				"arn:aws:s3:::'''+bucket_name+'''"
            					]
       					   }
					  ]
				   }'''
		 	)
        print(response)
        logger.debug("Updated new policy to S3 bucket.")
     else:
        logger.error("******Error in updating bucket policy, Manual intervention required!")
        sys.exit(1)

#Get existing policy and update new bucket policy to the bucket
def dest_update_policy(bucket_name):
  try:
     session = boto3.Session(profile_name='dev')
     client = session.client('s3')
     result = client.get_bucket_policy(Bucket=bucket_name)
     data=(result['Policy'])
     logger.debug("Getting existing policy from destination bucket and saving to a file. {}".format(data))
     formatjson=(json.loads(data))
     with open('./s3_bucket/template/old_dest_policy.json', 'w') as outfile:
                          json.dump(formatjson, outfile, sort_keys = False, indent = 4, ensure_ascii = False)
     original_policy = open('./s3_bucket/template/old_dest_policy.json', 'r').readlines()
     write_file = open('./s3_bucket/template/updated_dest_policy.json','w')
     policy='''{
            "Sid": "DAP-Admin-Source_Policy",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::506334935535:root"
            },
            "Action": "s3:*",
            "Resource": [
                "arn:aws:s3:::'''+bucket_name+'''",
                "arn:aws:s3:::'''+bucket_name+'''/*"
            ]
        },'''
     for line in original_policy:
               write_file.write(line)
               if '"Statement": [' in line:
                        new_line = "\t\t\t\t%s" %(policy)
                        write_file.write(new_line + "\n")
     write_file.close()
     updated_policy = open('./s3_bucket/template/updated_dest_policy.json', "r").read()
     logger.debug("Proceeding with updating the modified bucket policy to destination S3. Policy: {}".format(updated_policy))
     response = client.put_bucket_policy(
                        Bucket=bucket_name,
                        ConfirmRemoveSelfBucketAccess=False,
                        Policy=updated_policy
                   )
     status_code=response['ResponseMetadata']['HTTPStatusCode']
     if(status_code==204):
              logger.debug("Modified existing policy with cross account access has been updated in S3 destination bucket policy. Policy: {}".format(updated_policy))

  except ClientError as e:
     error_msg = (e.response['Error']['Message'])
     logger.debug('Unable to find an existing bucket policy in destination bucket. Error Message: "{}"'.format(error_msg))
     if (error_msg=="The bucket policy does not exist"):
        open('./s3_bucket/template/old_policy.json', 'w').close()
        logger.debug("Updating new bucket policy for bucket '{}'.\n".format(bucket_name))
        response = client.put_bucket_policy(
                        Bucket=bucket_name,
                        ConfirmRemoveSelfBucketAccess=False,
                        Policy='''{
				   "Version": "2012-10-17",
                                   "Statement": [
                                      {
                                           "Sid": "Example permissions",
                                           "Effect": "Allow",
                                           "Principal": {
                                                "AWS": "arn:aws:iam::506334935535:root"
                                            },
                                            "Action": "s3:*",
                                            "Resource": [
                                                "arn:aws:s3:::'''+bucket_name+'''",
                                                "arn:aws:s3:::'''+bucket_name+'''/*"
                                                   ]
                                            }
                                      ]
                                   }'''
                        )
        print(response)
        logger.debug("Updated new policy to S3 destination bucket.")
     else:
        logger.error("******Error in updating destination bucket policy, Manual intervention required!")
        sys.exit(1)


#Copy all files from prod to dev
def recursive_copy(src_bucket,src_path,dest_bucket,dest_path):
    timeout_sec = datetime.timedelta(minutes=20)
    try:
        process = Popen(['aws', 's3', 'cp', 's3://{}{}'.format(src_bucket,src_path), 's3://{}{}'.format(dest_bucket,dest_path), '--acl', 'bucket-owner-full-control', '--sse', 'AES256', '--recursive'], stdout=PIPE, stderr=PIPE)
        stdout, stderr = process.communicate()
        result = stdout.decode()
        if result:
           logger.debug('Begin copying files to the destination:\n{}'.format(stdout))
        else:
           logger.error('Unable to copy the object to destination:\n{}'.format(stderr))
    except TimeoutException:
        logger.warn("Found too much data to copy. Function fails if execeeds more than 10 Minutes.")
        logger.critical("Skipping copy function due to too much data, please select a different different folder having fewer objects")      
        pass

#Replace the newly added policy after copy with the old bucket policy
def replace_old_policy(bucket_name,profile,file_name):
      
        session = boto3.Session(profile_name=profile)
        client = session.client('s3')
        file_size = os.stat('./s3_bucket/template/'+file_name+'').st_size
        if(file_size!=0):
            original_policy = open('./s3_bucket/template/{}'.format(file_name), 'r').read()
            logger.debug("Replacing modified policy with the original policy. Policy: {}".format(original_policy))
            response = client.put_bucket_policy(
                        Bucket=bucket_name,
                        ConfirmRemoveSelfBucketAccess=False,
                        Policy=original_policy
                   )
            status_code=response['ResponseMetadata']['HTTPStatusCode']
            if(status_code==204):
                  logger.debug("Policy has been replaced successfully policy {}.".format(response))
        else:
            logger.warn("Bucket '{}' doesn't have any existing policy, proceeding to remove newly added policy!".format(bucket_name))
            del_policy=client.delete_bucket_policy(Bucket=bucket_name)
            try:
                  result = client.get_bucket_policy(Bucket=bucket_name)
                  data=(result['Policy'])
            except ClientError as e:
                  error_msg = (e.response['Error']['Message'])
                  if (error_msg=="The bucket policy does not exist"):
                        logger.debug('Bucket policy has been successfully removed from the Bucket "{}"'.format(bucket_name))
                        logger.debug('******Task has been completed******')
                  else:
                        logger.error('Unable to remove bucket policy from "{}"'.format(bucket_name))

#Initializing logger fgor debugginh
def init_logger():
       global logger
       logger = logging.getLogger('*S3 Prod to Dev Transfer*')
       logger.setLevel(logging.DEBUG)
       ch = logging.StreamHandler()
       ch.setLevel(logging.DEBUG)
       formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
       ch.setFormatter(formatter)
       logger.addHandler(ch)
       return logger

def main():
       init_logger()
       logger.debug("******Initializing data transfer process from Prod to Dev S3 Bucket******")
       logger.debug("Source Bucket: {}, Source Path: {}".format(src_bucket_name,src_key_path))
       logger.debug("Destination Bucket: {}, Destination Path: {}".format(dest_bucket_name,dest_key_path))
       get_update_policy(src_bucket_name)
       dest_update_policy(dest_bucket_name)
       recursive_copy(src_bucket_name,src_key_path,dest_bucket_name,dest_key_path)
       replace_old_policy(dest_bucket_name,'dev','old_dest_policy.json')
       replace_old_policy(src_bucket_name,'prod','old_policy.json')
       

if __name__ == '__main__':
    main()
    

sys.exit()
