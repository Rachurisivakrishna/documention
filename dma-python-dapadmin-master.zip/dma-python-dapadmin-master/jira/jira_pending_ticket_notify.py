import os
import sys
import json
import boto3
import urllib3
import requests
import optparse
from botocore.exceptions import ClientError
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

#### Credentials initialization ####
def login_init():

	 parser = optparse.OptionParser()
	 parser.add_option('-j', '--jira_user', action="store", dest="jira_user", help="Jira Username", default="")
	 parser.add_option('-p', '--jira_passwd', action="store", dest="jira_passwd", help="Jira Password", default="")
	 parser.add_option('-r', '--recepient', action="store", dest="recepient", help="Receiver Email", default="DAPOnsiteOffshore@hbo.com")
	 options, args = parser.parse_args()
         login_init.jira_user = options.jira_user
         login_init.jira_passwd = options.jira_passwd
         login_init.RCR_email = options.recepient

def get_jira_restapi():
	headers = {
	    	'Content-Type': 'application/json',
	}
	query='''project%20%3D%20DAT%20AND%20issuetype%20in%20(Incident%2C%20Problem%2C%20%22Service%20Request%22%2C%20%22Service%20Request%20with%20Approvals%22%2C%20Task)%20AND%20status%20in%20(Open%2C%20%22In%20Progress%22%2C%20Reopened%2C%20Escalated%2C%20%22Work%20in%20progress%22%2C%20%22Under%20investigation%22)%20AND%20created%20%3E%3D%20-20d%20AND%20updated%20%3C%20-2d'''
	url="https://10.118.129.18:443/rest/api/2/search?jql={}".format(query)
	response = requests.get(url, headers=headers, verify=False, auth=(login_init.jira_user, login_init.jira_passwd))
	op=(json.loads(response.content))
	ticket=op['issues']
	send_id=[]
	for i in ticket:
		ticket_id=(i['key'])
		title=(i['fields']['summary'])
		status=(i['fields']['status']['name'])
                assignee=(i['fields']['assignee']['name'])
                ticket_content=('ID: '+ticket_id+', STATUS: '+status+', TITLE: '+title+'<br>')
		send_id.append(ticket_content)
        send_notify(send_id)
        print("\n".join(send_id))



def send_notify(id_content):
    login_init()
    if (id_content): 
        SENDER = "DAPOperationsSupport@hbo.com"
        DLRECIPIENT = "Karthikeya.Chennuru@hbo.com"
        RECIPIENT = login_init.RCR_email
	SUBJECT = "ATTENTION: DAT Jira Pending Tickets Count - {}".format(len(id_content))
	# The HTML body of the email.
	BODY_HTML = """<p><span style="font-size: 10pt;">Hello DAP-Operations,</span></p><p><span style="font-size: 10pt;">Please find the below Jira tickets which has not been updated since last two days. Kindly prioritise the task and work on it.</span></p><p><span style="font-size: 10pt;">"""+('\n'.join(id_content))+"""<br></span></p><p>&nbsp;</p><p><span style="font-size: 10pt;">Thanks &amp; Regards,</span></p><p><span style="font-size: 10pt;">MTIS-Applications And Platform Support | DAP Operation Team</span></p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>"""

	# The character encoding for the email.
	CHARSET = "UTF-8"

	# Create a new SES resource and specify a region.
	client = boto3.client('ses',region_name="us-east-1")

	# Try to send the email.
	try:
    		#Provide the contents of the email.
    		response = client.send_email(
        	Destination={
		'ToAddresses': [
                	RECIPIENT,
            		],
		'BccAddresses': [
                	DLRECIPIENT,
		]	,
		},
       		Message={
            	'Body': {
                	'Html': {
                    		'Charset': CHARSET,
                    		'Data': BODY_HTML,
                		},
            		},
		'Subject': {
                		'Charset': CHARSET,
                		'Data': SUBJECT,
			},
		},
        	Source=SENDER,
		)

	# Display an error if something goes wrong.	
	except ClientError as e:
    		print(e.response['Error']['Message'])
  	else:
		print("Email sent! Message ID:"),
		print(response['MessageId'])


if __name__ == '__main__':
        login_init()
	get_jira_restapi()



sys.exit()

