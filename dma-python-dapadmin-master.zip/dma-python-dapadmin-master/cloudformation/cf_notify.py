#!/bin/python
############################################################################################################
########################################## Script to notify users ##########################################
############################################################################################################

import sys
import boto3
import logging
import optparse

def args_parse():
    """
    Argument parser function to receive all input variables
    """
    parser = optparse.OptionParser()
    parser.add_option('-s', '--stack_name', action="store", dest="stack_name", help="Input stack name", default="")
    parser.add_option('-b', '--build_no', action="store", dest="build_no", help="Jenkins Build number", default="")
    parser.add_option('-u', '--build_url', action="store", dest="build_url", help="Jenkins Build URL", default="")
    options, args = parser.parse_args()
    return options

def init_logger():
    """
    Initializing logger function for effective logging
    """
    global logger
    logger = logging.getLogger('CF')
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    return logger

def dap_notify(stack_name, status, build_no, build_url):
  """
  AWS SES to send cloud formation deploy notification to users.
  """
  logger.debug("Sending email notification.")
  # The subject line for the email.
  SUBJECT = "FAILED-CF STACK DEPLOYMENT-{}-BUILD-{}".format(stack_name, build_no)
  BODY_HTML = """<p><span style="font-size: 10pt; font-family: georgia, palatino;">Hello,</span></p>
<p><span style="font-size: 10pt; font-family: georgia, palatino;">CloudFormation stack has failed to deploy due to validation error. Please fix the issue in yaml file and retry.</span></p>
<p><span style="font-family: georgia, palatino;"><strong><span style="font-size: 10pt;">Stack Name: '%s'</span></strong></span></p>
<p><span style="font-family: georgia, palatino;"><strong><span style="font-size: 10pt;">Status: '%s'</span></strong></span></p>
<p><span style="font-family: georgia, palatino;"><strong><span style="font-size: 10pt;">Jenkins Build URL: '%s'</span></strong></span></p>
<p>&nbsp;</p>
<p><span style="font-size: 10pt; font-family: georgia, palatino;">***This is an Auto-generated email for a failed Cloudformation Deployment. Please check build logs for more updates.&nbsp;</span></p>""" %(stack_name, status, build_url)
  # The character encoding for the email.
  CHARSET = "UTF-8"
  session = boto3.Session(profile_name='dev')
  # Create a new SES resource and specify a region.
  client = session.client('ses')

  # Try to send the email.
  try:
    #Provide the contents of the email.
    response = client.send_email(
        Destination={
            'ToAddresses': [
                 'DAPOnsiteOffshore@hbo.com',
            ],
            'BccAddresses': [
                'DAPOnsiteOffshore@hbo.com',
            ],
        },
        Message={
            'Body': {
                'Html': {
                    'Charset': CHARSET,
                    'Data': BODY_HTML,
                },
            },
            'Subject': {
                'Charset': CHARSET,
                'Data': SUBJECT,
            },
        },
        Source='DAPOperationsSupport@hbo.com',
    )

  # Display an error if something goes wrong.
  except ClientError as e:
    logger.error("An error occured while sending email to DL '{}'. Error Response: {}".format('DAPOnsiteOffshore@hbo.com', e.response['Error']['Message']))
  else:
    logger.debug("Email notification sent to the user '{}'! Message ID: {}".format('DAPOnsiteOffshore@hbo.com', response['MessageId']))



def main():
    """
    Main function to call all sub function
    """
    init_logger()
    options=args_parse()
    dap_notify(options.stack_name, 'Validation_failure', options.build_no, options.build_url)
    


if __name__ == '__main__':
    main()


sys.exit()
