#!/usr/bin/python
############################################################################################################
####################### Script to get Cloud formation stack status and notify users ########################
############################################################################################################


import sys
import time
import boto3
import logging
import optparse
import threading


def args_parse():
    """
    Argument parser function to receive all input variables
    """
    parser = optparse.OptionParser()
    parser.add_option('-s', '--stack_name', action="store", dest="stack_name", help="Input stack name", default="")
    parser.add_option('-b', '--build_no', action="store", dest="build_no", help="Jenkins Build number", default="")
    parser.add_option('-u', '--build_url', action="store", dest="build_url", help="Jenkins Build URL", default="")
    options, args = parser.parse_args()
    return options


def init_logger():
    """
    Initializing logger function for effective logging
    """
    global logger
    logger = logging.getLogger('CF')
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    return logger

def stack_status(stack_name):
    """
    Get recent stack status
    """
    client = boto3.client('cloudformation')
    response = client.describe_stacks(
     StackName=stack_name,
     NextToken='None'
     )
    stack_status=response['Stacks'][0]['StackStatus']
    logger.debug("CloudFormation deployment status for stack name '{}' is '{}'".format(stack_name, stack_status))
    return(stack_status)


def wait_until_complete():
    """
    Loop and wait until the status gets failed or completed
    """
    t=threading.Timer(5, wait_until_complete)
    t.start()
    options=args_parse()
    stack_name=options.stack_name
    logger.debug("Stack Name: '{}'".format(stack_name))
    status=stack_status(stack_name)
    if(status=="CREATE_COMPLETE"):
      logger.debug("CloudFormation has deployed the stack '{}' succesfully, Status: '{}'".format(stack_name, status))
      t.cancel()
      dap_notify(stack_name, status, options.build_no, options.build_url, 'complete')
      sys.exit(0)
    elif(status=="ROLLBACK_COMPLETE"):
      logger.error("CloudFormation stack '{}' has failed to deploy!, Status: '{}'".format(stack_name, status))
      logger.error("Force exiting due to failure, Response Status: '{}'".format(status))
      t.cancel()
      dap_notify(stack_name, status, options.build_no, options.build_url, 'rollback')
      sys.exit(1)
    else:
      logger.debug("CloudFormation stack '{}' deployment is currently in-progress, Status: '{}'".format(stack_name, status))


def dap_notify(stack_name, status, build_no, build_url, check):
  """
  AWS SES to send cloud formation deploy notification to users.
  """
  logger.debug("Sending email notification.")
  # The subject line for the email.
  SUBJECT = "CF STACK DEPLOYMENT-{}-BUILD-{}".format(stack_name, build_no)
  if(check=='complete'):
  # The HTML body of the email for success complete.
   BODY_HTML = """<p><s`pan style="font-size: 10pt; font-family: georgia, palatino;">Hello,</span></p>
<p><span style="font-family: georgia, palatino;">CloudFormation stack has been deployed successfully.</span></p>
<p><span style="font-family: georgia, palatino;"><strong><span style="font-size: 10pt;">Stack Name: '%s'</span></strong></span></p>
<p><span style="font-family: georgia, palatino;"><strong><span style="font-size: 10pt;">Status: '%s'</span></strong></span></p>
<p><span style="font-family: georgia, palatino;"><strong><span style="font-size: 10pt;">Jenkins Build URL: '%s'</span></strong></span></p>
<p>&nbsp;</p>
<p><span style="font-size: 10pt; font-family: georgia, palatino;">***This is an Auto-generated email for successful Cloudformation Deployment. Please check build logs for more information.&nbsp;</span></p>"""  %(stack_name, status, build_url)
  else:
   BODY_HTML = """<p><span style="font-size: 10pt; font-family: georgia, palatino;">Hello,</span></p>
<p><span style="font-size: 10pt; font-family: georgia, palatino;">CloudFormation stack has failed to deploy.</span></p>
<p><span style="font-family: georgia, palatino;"><strong><span style="font-size: 10pt;">Stack Name: '%s'</span></strong></span></p>
<p><span style="font-family: georgia, palatino;"><strong><span style="font-size: 10pt;">Status: '%s'</span></strong></span></p>
<p><span style="font-family: georgia, palatino;"><strong><span style="font-size: 10pt;">Jenkins Build URL: '%s'</span></strong></span></p>
<p>&nbsp;</p>
<p><span style="font-size: 10pt; font-family: georgia, palatino;">***This is an Auto-generated email for a failed Cloudformation Deployment. Please check build logs for more updates.&nbsp;</span></p>""" %(stack_name, status, build_url)
  # The character encoding for the email.
  CHARSET = "UTF-8"
  session = boto3.Session(profile_name='dev')
  # Create a new SES resource and specify a region.
  client = session.client('ses')

  # Try to send the email.
  try:
    #Provide the contents of the email.
    response = client.send_email(
        Destination={
            'ToAddresses': [
                 'DAPOnsiteOffshore@hbo.com',
            ],
            'BccAddresses': [
                'DAPOnsiteOffshore@hbo.com',
            ],
        },
        Message={
            'Body': {
                'Html': {
                    'Charset': CHARSET,
                    'Data': BODY_HTML,
                },
            },
            'Subject': {
                'Charset': CHARSET,
                'Data': SUBJECT,
            },
        },
        Source='DAPOperationsSupport@hbo.com',
    )

  # Display an error if something goes wrong.
  except ClientError as e:
    logger.error("An error occured while sending email to DL '{}'. Error Response: {}".format('DAPOnsiteOffshore@hbo.com', e.response['Error']['Message']))
  else:
    logger.debug("Email notification sent to the user '{}'! Message ID: {}".format('DAPOnsiteOffshore@hbo.com', response['MessageId']))



def main():
    """
    Main function to call all sub function
    """
    init_logger()
    wait_until_complete()



if __name__ == '__main__':
    main()


sys.exit()
