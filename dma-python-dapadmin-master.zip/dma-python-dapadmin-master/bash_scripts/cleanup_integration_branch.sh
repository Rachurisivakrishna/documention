#!/bin/bash

#############################################################
####SCRIPT TO CLEANUP UNUSED GIT BRANCH OLDER THAN 7 DAYS####
#############################################################

for branch in $(git branch | sed /\*/d); do
  if [ -z "$(git log -1 --since='7 days ago' -s $branch)" ] && [[ $branch == *"integrationdev-"* ]]; then
    git branch -D $branch
    {
       git push origin --delete $branch
    } || {
       echo "Unable to find remote branch $branch!"
    }
  fi
done
