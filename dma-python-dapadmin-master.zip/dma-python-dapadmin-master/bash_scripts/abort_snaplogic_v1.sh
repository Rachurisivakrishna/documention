#!/usr/bin/bash
source ~/.bash_profile

#########################################################
#################   Version: 1   ########################
################# SNAPLOGIC ABORT #######################
#########################################################


# Getting Pipeline name as input parameter
usage() { echo "Usage: $0 [-p <pipeline_name>]" 1>&2; exit 1; }

# Getopsts for argument parsing
while getopts ":p:" o; do
    case "${o}" in
        p)
            p=${OPTARG}
            ;;
        *)
            usage
            ;;
    esac
done
shift $((OPTIND-1))

# Show 'USAGE' function in terminal if parameters are empty
if [ -z "${p}" ] ; then
    usage
fi

# Define and Assign input arguments to variables
PIPELINE_NAME=${p}

# Echo parameters
echo "ENVIRONMENT : $ENV"
echo "PIPELINE NAME : $PIPELINE_NAME"

# Get run time id of the pipeline
RUNTIME_URL="https://elastic.snaplogic.com/api/1/rest/public/runtime/$ENV?state=Started&pipe_name=$PIPELINE_NAME"
RUUID=$(curl --silent -u 'DAPOperationsSupport@hbo.com:<<PASSWORD>>' "$RUNTIME_URL"  | \
python -c 'import sys,json
json_parse=json.load(sys.stdin)
try:
 print(json_parse["response_map"]["entries"][0]["id"])
except:
 print("Failed")')


# If unable to obtain Runtime UUID, abort the script
if [[ "$RUUID" == "Failed" ]]; then
   echo "RUNTIME ID STATUS: Failed to get pipeline Runtime ID, It could possibly due to pipeline not running or started."
   echo "Terminating the bash script.!!!"
   exit 1
fi



# Curl -X POST to stop the pipeline
REST_URL="https://elastic.snaplogic.com/api/1/rest/public/runtime/stop/$ENV/$RUUID"

echo "RUNTIME UID: $RUUID"
echo "-------------------------------------------------------------------------------------"
echo "Stopping Pipeline '$PIPELINE_NAME' with runtime id $RUUID"
ABORT_OP=`curl -k --silent -X POST -u 'DAPOperationsSupport@hbo.com:<<PASSWORD>>' $REST_URL`
echo "Abort Status: $ABORT_OP"
echo "--------------------------------------------------------------------------------------"

# Function to validate whether the pipeline has stopped or not
get_pipeline_status () {
 RUNTIME_URL="https://elastic.snaplogic.com/api/1/rest/public/runtime/$ENV/$RUUID"
 state=$(curl --silent -u 'DAPOperationsSupport@hbo.com:PASSWORD' "$RUNTIME_URL"  | \
python -c 'import sys,json
json_parse=json.load(sys.stdin)
try:
 print(json_parse["response_map"]["state"])
except:
 print("IN-PROGRESS")' )
}

# Loops and checks the pipeline status until it is in stopped state
while get_pipeline_status
do
        get_pipeline_status
        echo "Checking '$PIPELINE_NAME' Snaplogic pipeline status: $state"
        if [[ "$state" == "Stopped" ]]; then
            echo "************************************************************************"
            echo "************************************************************************"
            echo "**              Pipeline has been aborted successfully!               **"
            echo "************************************************************************"
            echo "************************************************************************"
            exit 0
        else
            sleep 5
        fi
done

exit 0
