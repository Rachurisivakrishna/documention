#!/bin/bash

#####################################################################################
#################################### Version 1 ######################################
############################ Assume Role for Appsflyer ##############################
#####################################################################################


# Date 1 : Current date
dt1=$(date -u +"%Y-%m-%dT%H:%M:%1NZ")
# Compute the seconds since epoch for date 1
t1=`date --date="$dt1" +%s`

# Date 2 : Expiration date
dt2=$(grep 'EXPIRATION=*' ~/.bash_profile  | sed -e 's/EXPIRATION=//g')
#dt2="2019-07-29T15:41:39Z"
# Compute the seconds since epoch for date 2
t2=`date --date="$dt2" +%s`

# Compute the difference in dates in seconds
let "tDiff=$t2-$t1"
# Compute the approximate hour difference
let "mDiff=$tDiff/60"
echo "Approx minutes diff b/w Current time $dt1 & AWS key expiration $dt2, $mDiff Minutes Left"

#Parse AWS keys from assume role json response
json_parse() {
echo $aws_assume_role | \
python -c 'import sys,os,json
json_parse=json.load(sys.stdin)

try:
 access_key=(json_parse["Credentials"]["AccessKeyId"])
 secret_key=(json_parse["Credentials"]["SecretAccessKey"])
 session=(json_parse["Credentials"]["SessionToken"])
 expiration=(json_parse["Credentials"]["Expiration"])
 os.system("echo AWS_ACCESS_KEY_ID={} >> ~/.bash_profile".format(access_key))
 os.system("echo AWS_SECRET_ACCESS_KEY={} >> ~/.bash_profile".format(secret_key))
 os.system("echo AWS_SESSION_TOKEN={} >> ~/.bash_profile".format(session))
 os.system("echo EXPIRATION={} >> ~/.bash_profile".format(expiration))

except:
 print("Error: Unable to parse credentials from assume role output.")'
}

# Remove old keys from ~/.bash_profile
remove_old_keys() {
sed -i '/AWS_ACCESS_KEY_ID/d' ~/.bash_profile
sed -i '/AWS_SECRET_ACCESS_KEY/d' ~/.bash_profile
sed -i '/AWS_SESSION_TOKEN/d' ~/.bash_profile
sed -i '/EXPIRATION/d' ~/.bash_profile
}

# Check if time is less than 0 minutes between expiration time and current time
if [ $mDiff -lt 0 ];
then
    echo "Retrigger assume role command for Appsflyer."
    aws_assume_role=$(aws sts assume-role --role-arn "arn:aws:iam::873747752477:role/hbo_s3_access" --role-session-name "appsfyler")
    echo "Removing Expired keys from ~/.bash_profile"
    remove_old_keys
    echo "Parsing new credentials and append to ~/.bash_profile"
    json_parse
    source  ~/.bash_profile
else
    echo "AWS keys are not expired to trigger assume role, $mDiff minutes left for expiry"
    source  ~/.bash_profile
fi

# List the file to verify if credentials are working
AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN=$AWS_SESSION_TOKEN aws s3 ls s3://af-ext-reports/49b2-acc-W2HEmSio/data-locker-hourly/
ls_result=$?

if [ $ls_result = 0 ]
then
   echo "Successfully listed S3 objects from s3://af-ext-reports."
else
   echo "Error: Not able to list the objects from s3://af-ext-reports."
   echo "Error: Please check if credentials are valid."
   exit 1
fi
