#!/bin/bash

####################################################################
########################### Version : 1 ############################
############## PROD BACKUP TO BETA TIGERGRAPH RESTORE ##############
####################################################################

#### Assign variables ####
PROD_BUCKET='hbo-backup-tigergraph-prod'
PROD_AWS_PROFILE='tigergraph_prod'
BETA_BUCKET='hbo-backup-tigergraph-beta'
BETA_AWS_PROFILE='tigergraph_beta'
DATA_LOCATION='/tmp/'
DATA=$1


#### Download files from prod tigergraph to local destination ####
echo "Getting data $DATA from $PROD_BUCKET and copying into $DATA_LOCATION"
aws s3 cp s3://$PROD_BUCKET/$DATA $DATA_LOCATION --recursive --profile $PROD_AWS_PROFILE


#### Upload download data back to beta tigergraph s3 bucket ####
echo "Copying Production Tigergraph data $DATA into Beta Tigergraph S3 bucket $BETA_BUCKET."
aws s3 cp /tmp/$DATA s3://$DEST_BUCKET/ --recursive --profile $BETA_AWS_PROFILE

sleep 5s

#### Make a gbar restore on beta ####
echo "Restore Production data $DATA into Beta Tigergraph"
gbar restore $DATA
restore_result=$?
if [[ $restore_result = 0 ]]; then
  echo "Restore completed successfully."
  exit 0
else
  echo "Restore failed for backup $DATA."
  exit 1
fi
