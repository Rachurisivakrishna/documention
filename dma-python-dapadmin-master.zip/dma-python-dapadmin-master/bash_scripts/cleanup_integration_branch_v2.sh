
#!/bin/bash


#############################################################
####SCRIPT TO CLEANUP UNUSED GIT BRANCH OLDER THAN 1 DAY####
####################     Version: V3    #####################
#############################################################


#Get all remote branhces in local
for b in `git branch -r | grep -i integrationdev- | grep -v -- '->'`; do git branch --track ${b##origin/} $b; done

#Loop through available integration branches and remove which are older than 1 day.
for branch in $(git branch | cut -c3- | grep -i integrationdev- ); do
  if [ -z "$(git log -1 --since='9 Hours ago' -s $branch)" ] && [[ $branch == *"integrationdev-"* ]]; then
     git branch -D $branch
    {
     git push origin --delete $branch
    } || {
     echo "Unable to find remote branch $branch!"
    }
  fi
done
