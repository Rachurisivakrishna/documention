#!/usr/bin/bash

#########################################################
#################   Version: 1    #######################
################ SNOWFLAKE INVOKE  ######################
#########################################################


#Getting Bearer token, folder name and as input parameter

usage() { echo "Usage: $0 [-b <bearer_token>]  [-f <folder_name>] [-p <project_space>]" 1>&2; exit 1; }

#Getopsts args parser

while getopts ":b:f:p:" o; do
    case "${o}" in
        b)
            b=${OPTARG}
            ;;
        f)
            f=${OPTARG}
            ;;
        p)
            p=${OPTARG}
            ;;
        *)
            usage
            ;;
    esac
done
shift $((OPTIND-1))

#show usage if parameters are empty

if [ -z "${b}" ] || [ -z "${f}" ] || [ -z "${p}" ] ; then
    usage
fi

#Assign input arguments to variable
BEARER_TOKEN=${b}
PROJECT_SPACE=${p}
FOLDER_NAME=${f}

#Curl response for the iunvoke
URL="$SNAPLOGIC_URL/$ENV/$FOLDER_NAME/$PROJECT_SPACE"

invoke_response=$(curl -o -I -L -s -w "%{http_code}" -H "Authorization: Bearer $BEARER_TOKEN" -H "Content-Type: application/json" "$URL" --insecure)

#Verify curl status codes

if [[ "$invoke_response" -ne 200 ]]; then

  echo "Invoke response received with failure, status code: $invoke_response!"

else

  echo "Invoke response is success, status code $invoke_response!"

fi


exit 0
