#!/bin/bash

#### Script to port forward from 8080 to 443 ####
#### NOTE: Always run this script as root user ####

yum -y install iptables-services
iptables -I INPUT 1 -p tcp --dport 8080 -j ACCEPT
iptables -I INPUT 1 -p tcp --dport 443 -j ACCEPT
iptables -A PREROUTING -t nat -i eth0 -p tcp --dport 443 -j REDIRECT --to-port 8080
iptables-save > /etc/sysconfig/iptables
systemctl enable iptables
