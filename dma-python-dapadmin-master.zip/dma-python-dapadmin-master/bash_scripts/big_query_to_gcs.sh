#!/bin/bash

############################################################
######################## Version: ! ########################
######### Big Query TO Google Cloud Storage (GCS) ##########
############################################################

source /etc/profile && source ~/.bash_profile && shopt -s expand_aliases


#Formatting date into %Y%m%d format
DATA=`date`
YEAR=$(date +"%Y")
MONTH=$(date +"%m")
DAY=$(date +"%d")
DATE=`date -d "${DATA}" '+%Y%m%d'`

#Arguments
APP_NAME="dcm_attributes"
TABLE_NAME="dt-files-227615:DT_Log_Files.query_result_hurely_temp_id"
GCS_BUCKET="tests-download"
AWS_BUCKET="hbo-dap-dcm"
FILE_FORMAT="CSV"
FILE_FORMAT_LOWER=$(echo "$FILE_FORMAT" | tr 'A-Z' 'a-z')
FILE_NAME="$APP_NAME"_"$DATE"."$FILE_FORMAT_LOWER"
LOCAL_STORAGE_PATH="/dap/tmp/$FILE_NAME"


echo "LOG `date` : File name is :$FILE_NAME"
> "$LOCAL_STORAGE_PATH"

echo "LOG `date` : Begin extracting the table $TABLE_NAME as $FILE_FORMAT file."

bqext=$(bq extract --destination_format $FILE_FORMAT $TABLE_NAME gs://$GCS_BUCKET/$FILE_NAME &> /tmp/gcs_status_file.txt)

bq_out=$(tail -n 1 /tmp/gcs_status_file.txt)
echo $bq_out
if [[ $bq_out == *"DONE"* ]]; then

    printf '%s\n' "$bq_out"
    echo "LOG `date` : Big query table extraction status is completed."
    echo "LOG `date` : Copying data from GCS gs://$GCS_BUCKET/$FILE_NAME to local storage $LOCAL_STORAGE_PATH"
    gsutil cp gs://$GCS_BUCKET/$FILE_NAME $LOCAL_STORAGE_PATH
    echo "LOG `date` : Copying data from $LOCAL_STORAGE_PATH to AWS S3 Bucket $AWS_BUCKET"
    aws s3 cp $LOCAL_STORAGE_PATH s3://$AWS_BUCKET/googlecloud/$APP_NAME/$FILE_FORMAT_LOWER/yr=$YEAR/mo=$MONTH/dt=$DATE/$FILE_NAME --sse AES256

else

    echo "LOG `date` : Big query is unable to extract data from table to GCS"
fi
