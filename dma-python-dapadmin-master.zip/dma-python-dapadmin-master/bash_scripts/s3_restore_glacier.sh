#!/bin/bash

obj=$(aws s3api list-objects --bucket $1 --query 'Contents[?StorageClass==`GLACIER`].['Key']' --prefix $2 --output text --profile $3)
for keys in $obj
do
    echo $keys
    aws s3api restore-object --bucket $1 --key $keys --restore-request '{"Days":'$4',"GlacierJobParameters":{"Tier":"Bulk"}}' --profile $3
    aws s3api head-object --bucket $1 --key $keys --profile $3
done
