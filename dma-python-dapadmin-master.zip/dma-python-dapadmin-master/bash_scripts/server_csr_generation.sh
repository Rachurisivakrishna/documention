#!/bin/bash

#############################################################################################################
## Generate CSR and upload to S3 bucket.

# Getting Bearer token, folder name and as input parameter
usage() { echo "Usage: $0 [-h <host_name>]" 1>&2; exit 1; }

# Getopsts for argument parsing
while getopts ":h:" o; do
    case "${o}" in
        h)
            h=${OPTARG}
            ;;
        *)
            usage
            ;;
    esac
done
shift $((OPTIND-1))

# Show 'USAGE' function in terminal if parameters are empty
if [ -z "${h}" ] ; then
    usage
fi
read -p 'Access ID: ' uservar
read -sp 'Secret Acess Key: ' passvar


# Define and Assign input arguments to variables
host_name=${h}
app_name=$(hostname --ip-address| sed "s/127.0.0.1//g" | sed "s/ //g" | tr "." _)

echo "**********************************************************************************"
echo "Creating CSR directory in present working directory, $PWD"
rm -rf ./${app_name}_csr
mkdir ./${app_name}_csr

echo "Formatting Input hostname.. "
server_name=$(echo "$host_name" | tr "-" _ | tr "." _  | tr A-Z a-z )

if [ -d "$PWD/${app_name}_csr" ]; then
    # Take action if $DIR exists. #
    echo "CSR Directory created, under $PWD."
    echo "Proceeding to generate CSR."
    # Generate CSR
    openssl req -nodes -newkey rsa:2048 -keyout ./${app_name}_csr/"$server_name"_server.key -out ./${app_name}_csr/"$server_name"_server.csr -subj "/C=US/ST=New York/L=New York/O=HBO/OU=MTIS/CN=$host_name/emailAddress=DAPOperationsSupport@hbo.com"

    echo "Checking if the Server key file exists."
    key="$PWD"/${app_name}_csr/"$server_name"_server.key
    csr="$PWD"/${app_name}_csr/"$server_name"_server.csr
    # Check if csr is generated
    if [ ! -f $key ] && [ ! -f "$csr" ] ; then
       echo "Server Key and CSR generation failed, please try."
    else
       echo "${server_name}_server.key is generated."
       echo "${server_name}_server.csr is generated."
       # Print output of csr
       openssl req -in $csr -noout -text
       echo "Uploading CSR files and directory to AWS S3 bucket."
       AWS_ACCESS_KEY_ID=$uservar AWS_SECRET_ACCESS_KEY=$passvar aws s3 cp "$PWD"/${app_name}_csr s3://hbo-dap-ops-dev/csr/${app_name}_csr/ --recursive --region us-east-1
    fi

else
    echo "Unable to find csr directory. "
    exit 1
fi

exit 0
