#!bin/bash

###############################################################################################
############ Script: Copy objects between Source and Destination with Object Limit ############
###############################################################################################

## Getting inputs from user
SOURCE_BUCKET_NAME=$1
SOURCE_PATH_OBJ=$2
DESTINATION_BUCKET_NAME=$3
DESTINATION_PATH_OBJ=$4
MAX_ITEMS=$5
ENV=$6

## Calculating length of prefix to remove delimiter '\'
LEN_PREFIX=$(expr ${#PATH_OBJ} + 1)

## Limit no of objects using max-items, loop and copy objects one by one
for key in $(aws s3api list-objects --bucket $BUCKET_NAME --prefix $PATH_OBJ --max-items $MAX_ITEMS --query 'Contents[].Key' --profile prod --output text)
do
  if [[ -z "$key" ]]; then
     no_data='0'
  else
     aws s3 mv s3://$SOURCE_BUCKET_NAME/$SOURCE_PATH_OBJ/$key|cut -c $LEN_PREFIX- s3://$DESTINATION_BUCKET_NAME/$DESTINATION_PATH_OBJ/ --profile $ENV
  fi
done
~
