import os
import sys
import csv
import time
import boto3
import logging
import optparse
import botocore
from logging import handlers
from botocore.exceptions import ClientError
from logging.handlers import RotatingFileHandler


session = boto3.Session(profile_name='dev', region_name='us-east-1')


def args_parse():
  """
  Argument parser function to receive all input variables
  """
  parser = optparse.OptionParser()
  parser.add_option("-e", "--env", action="store", dest="env", help="query string", default="")
  parser.add_option("-c", "--commit", action="store", dest="commit_id", help="query string", default="")
  parser.add_option("-p", "--gitpr", action="store", dest="git_pr", help="query string", default="")
  parser.add_option("-u", "--url", action="store", dest="jenkins_url", help="query string", default="")
  parser.add_option("-n", "--build_no", action="store", dest="build_no", help="query string", default="")
  parser.add_option("-l", "--logs", action="store", dest="build_logs", help="query string", default="")
  parser.add_option("-s", "--status", action="store", dest="build_status", help="query string", default="")
  parser.add_option("-b", "--buildname", action="store", dest="build_name", help="query string", default="")
  parser.add_option("-g", "--gituser", action="store", dest="git_commit_user", help="query string", default="")
  parser.add_option("-f", "--gitfiles", action="store", dest="git_files", help="query string", default="")
  options, args = parser.parse_args()
  return options

def init_logger():
  """
  Initializing logger function for log parsing
  """
  global logger
  logger = logging.getLogger('-')
  logger.setLevel(logging.DEBUG)
  formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
  ch = logging.StreamHandler()
  ch.setLevel(logging.DEBUG)
  ch.setFormatter(formatter)
  logger.addHandler(ch)
  wr_formatter = logging.Formatter("%(asctime)s-%(levelname)s-%(message)s<br/>")
  fh = handlers.RotatingFileHandler('offboard_user.log', maxBytes=(1048576*5), backupCount=7)
  fh.setFormatter(wr_formatter)
  logger.addHandler(fh)
  return logger

def send_email(env, git_commit_id, git_pr, jenkins_url, jenkins_no, build_name, build_logs, status, git_commit_user, files_changed):
  """
  Call AWS SES to send notification to DAP support.
  """
  logger.debug("Sending email notification")
  if(status=="failure"):
  # The subject line for the email.
      SUBJECT = "{} JENKINS DEPLOYMENT {}- BUILD NO: {} - FAILURE".format(env, build_name, jenkins_no)

  # The HTML body of the email.
      BODY_HTML = """<p>Hello,</p>
<p>Jenkins job has failed to deploy. Please find the error details below.</p>
<p>Github Commit User: %s</p>
<p>Github Commit ID: %s</p>
<p>Jenkins Job URL: %s</p>
<p>Jenkins Build No: %s</p>
<p>Files Changed in Commit:</p>
<p><span style="font-size: 10pt;">"""+('\n'.join(files_changed))+"""</span></p>
<p>Jenkins Log: <span style="background-color: #ff0000;">%s</span></p>
<p>---------------------------------------------------------------------------------------</p>
<p><span style="font-size: 12.0pt; font-family: 'Times New Roman',serif;">***This is an Auto-generated email for a failed Jenkins deployment, please fix the error and push the changes to Github for retriggering the build.</span></p>
<p><span style="font-size: 10.0pt;">Thanks &amp; Regards,</span></p>
<p><span style="font-size: 10.0pt;">MTIS-Applications And Platform Support | DAP Operation Team</span></p>
<p>&nbsp;</p>"""  %(git_commit_user, git_commit_id, jenkins_url, jenkins_no, build_logs)
  elif(status=="success"):

      SUBJECT = "{} JENKINS DEPLOYMENT {}- BUILD NO: {} - SUCCESS".format(env, build_name, jenkins_no)
      BODY_HTML = """<p>Hello,</p>
<p>Jenkins job has deployed sccessfully. Please approve the pull request to push the code to production.</p>
<p>Git Commit User: %s</p>
<p>Github Commit ID: %s</p>
<p>Github Pull-Request: %s</p>
<p>Files Changed in Commit:</p>
<p><span style="font-size: 10pt;">"""+('\n'.join(files_changed))+"""</span></p>
<p>Jenkins Job URL: %s</p>
<p>Jenkins Build No: %s</p>
<p>Jenkins Log: %s</p>
<p>---------------------------------------------------------------------------------------</p>
<p><span style="font-size: 12.0pt; font-family: 'Times New Roman',serif;">***This is an Auto-generated email for a successful Jenkins deployment, please approve the Pull-request to push the code into production.</span></p>
<p><span style="font-size: 10.0pt;">Thanks &amp; Regards,</span></p>
<p><span style="font-size: 10.0pt;">MTIS-Applications And Platform Support | DAP Operation Team</span></p>
<p>&nbsp;</p>""" %(git_commit_user, git_commit_id, git_pr, jenkins_url, jenkins_no, build_logs)
  elif(status=="prod-success"):

      SUBJECT = "{} JENKINS DEPLOYMENT {}- BUILD NO: {} - SUCCESS".format(env, build_name, jenkins_no)
      BODY_HTML = """<p>Hello,</p>
<p>Jenkins job has deployed sccessfully into production.&nbsp;</p>
<p>Jenkins Job URL: %s</p>
<p>Jenkins Build No: %s</p>
<p>Files Changed in Commit:&nbsp;</p>
<p><span style="font-size: 10pt;">"""+('\n'.join(files_changed))+"""</span></p>
<p>Jenkins Log: %s</p>
<p>---------------------------------------------------------------------------------------</p>
<p><span style="font-size: 12.0pt; font-family: 'Times New Roman',serif;">***This is an Auto-generated email for a successful Jenkins deployment into production.</span></p>
<p><span style="font-size: 10.0pt;">Thanks &amp; Regards,</span></p>
<p><span style="font-size: 10.0pt;">MTIS-Applications And Platform Support | DAP Operation Team</span></p>
<p>&nbsp;</p>""" %(jenkins_url, jenkins_no, build_logs)
  else:
      logger.debug("Status not provided for sending email, ignoring...")

  # The character encoding for the email.
  CHARSET = "UTF-8"

  # Create a new SES resource and specify a region.
  client = session.client('ses')

  # Try to send the email.
  try:
    #Provide the contents of the email.
    response = client.send_email(
        Destination={
            'ToAddresses': [
                'DAPOnsiteOffshore@hbo.com',
            ],
            'BccAddresses': [
                'DAPOnsiteOffshore@hbo.com',
            ],
        },
        Message={
            'Body': {
                'Html': {
                    'Charset': CHARSET,
                    'Data': BODY_HTML,
                },
            },
            'Subject': {
                'Charset': CHARSET,
                'Data': SUBJECT,
            },
        },
        Source='DAPOperationsSupport@hbo.com',
    )

  # Display an error if something goes wrong.
  except ClientError as e:
    logger.error("An error occured while sending email to DAP Admin & Suppport. Error Response: {}".format(e.response['Error']['Message']))
  else:
    logger.debug("Email sent to DAP Admin & Support! Message ID: {}".format(response['MessageId']))


def main():
  init_logger()
  options=args_parse()
  send_email(options.env, options.commit_id, options.git_pr, options.jenkins_url, options.build_no, options.build_name, options.build_logs, options.build_status, options.git_commit_user, options.git_files)

if __name__ == '__main__':
       main()

sys.exit()
