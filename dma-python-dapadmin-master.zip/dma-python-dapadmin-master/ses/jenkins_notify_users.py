import os
import sys
import csv
import time
import boto3
import logging
import optparse
import botocore
from logging import handlers
from botocore.exceptions import ClientError
from logging.handlers import RotatingFileHandler


session = boto3.Session(profile_name='dev', region_name='us-east-1')


def args_parse():
  """
  Argument parser function to receive all input variables
  """
  parser = optparse.OptionParser()
  parser.add_option("-e", "--env", action="store", dest="env", help="query string", default="")
  parser.add_option("-r", "--branch", action="store", dest="git_branch", help="query string", default="")
  parser.add_option("-C", "--commitdetails", action="store", dest="commit_details", help="query string", default="")
  parser.add_option("-u", "--url", action="store", dest="jenkins_url", help="query string", default="")
  parser.add_option("-n", "--build_no", action="store", dest="build_no", help="query string", default="")
  parser.add_option("-l", "--logs", action="store", dest="build_logs", help="query string", default="")
  parser.add_option("-s", "--status", action="store", dest="build_status", help="query string", default="")
  parser.add_option("-b", "--buildname", action="store", dest="build_name", help="query string", default="")
  parser.add_option("-d", "--email", action="store", dest="email", help="query string", default="")
  parser.add_option("-t", "--tag", action="store", dest="tag_version", help="query string", default="")
  options, args = parser.parse_args()
  return options

def init_logger():
  """
  Initializing logger function for log parsing
  """
  global logger
  logger = logging.getLogger('-')
  logger.setLevel(logging.DEBUG)
  formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
  ch = logging.StreamHandler()
  ch.setLevel(logging.DEBUG)
  ch.setFormatter(formatter)
  logger.addHandler(ch)
  wr_formatter = logging.Formatter("%(asctime)s-%(levelname)s-%(message)s<br/>")
  fh = handlers.RotatingFileHandler('offboard_user.log', maxBytes=(1048576*5), backupCount=7)
  fh.setFormatter(wr_formatter)
  logger.addHandler(fh)
  return logger

def send_email(env, git_branch, git_commit_det, jenkins_url, jenkins_no, build_name, build_logs, status, dl_email, tag_version):
  """
  Call AWS SES to send notification to DAP support.
  """
  logger.debug("Sending email notification to the distribution lists.")
  if(status=="failure"):
  # The subject line for the email.
      SUBJECT = "FAILURE - JENKINS {} JOB-{}".format(build_name, jenkins_no)

  # The HTML body of the email.
      BODY_HTML = """<p>Hello,</p>
<p>Jenkins job has failed to deploy. Please find the error details below.</p>
<div><span style="font-family: tahoma, arial, helvetica, sans-serif;"><strong><span style="font-size: 9pt;">Jenkins Build No: """+(jenkins_no)+"""</span></strong></span></div>
<p><span style="font-family: tahoma, arial, helvetica, sans-serif;"><strong><span style="font-size: 9pt;">Jenkins Job URL: """+(jenkins_url)+"""</span></strong></span></p>
<table style="border-collapse: collapse; width: 88.7564%; height: 40px;" border="1">
<tbody>
<tr style="height: 22px;">
<td style="width: 100%; text-align: center; height: 22px;"><span style="font-family: tahoma, arial, helvetica, sans-serif;"><strong><span style="font-size: 9pt;">*** <span style="text-decoration: underline;">GIT COMMIT DETAILS </span>***</span></strong></span></td>
</tr>
<tr style="height: 18px;">
<td style="width: 100%; height: 18px;"><span style="font-family: 'courier new', courier;"><strong><span style="font-size: 9pt;">"""+(git_commit_det.replace(' ', '<br>'))+"""</span></strong></span></td>
</tr>
</tbody>
</table>
<div>&nbsp;</div>
<table style="border-collapse: collapse; width: 89.0977%; height: 36px;" border="1">
<tbody>
<tr style="height: 19px;">
<td style="width: 100%; text-align: center; height: 19px;"><span style="font-family: tahoma, arial, helvetica, sans-serif;"><span style="font-size: 9pt;"><strong>*** </strong></span><span style="font-size: 9pt;"><span style="text-decoration: underline;"><strong>JENKINS PIPELINE LOG</strong></span><strong>&nbsp; ***</strong></span></span></td>
</tr>
<tr style="height: 18px;">
<td style="width: 100%; height: 17px;"><span style="font-size: 9pt; background-color: #ffcc99; font-family: 'courier new', courier;">"""+(build_logs)+"""</span></td>
</tr>
</tbody>
</table>
<p><span style="font-size: 12.0pt; font-family: 'Times New Roman',serif;">***This is an Auto-generated email for a failed Jenkins deployment, please fix the bug and push the changes to Github for retriggering the build.</span></p>
<p><span style="font-size: 10.0pt;">Thanks &amp; Regards,</span></p>
<p><span style="font-size: 10.0pt;">MTIS-Applications And Platform Support | DAP Operation Team</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>"""
  elif(status=="success"):

      SUBJECT = "SUCCESS - JENKINS {} JOB-{}".format(build_name, jenkins_no)
      BODY_HTML = """<p>Hello,</p>
<p>Jenkins pipeline has been deployed successfully. Please find the details below.</p>
<div><span style="font-family: tahoma, arial, helvetica, sans-serif;"><strong><span style="font-size: 9pt;">Jenkins Build No: """+(jenkins_no)+"""</span></strong></span></div>
<p><span style="font-family: tahoma, arial, helvetica, sans-serif;"><strong><span style="font-size: 9pt;">Jenkins Job URL: """+(jenkins_url)+"""</span></strong></span></p>
<table style="border-collapse: collapse; width: 88.7564%; height: 40px;" border="1">
<tbody>
<tr style="height: 22px;">
<td style="width: 100%; text-align: center; height: 22px;"><span style="font-family: tahoma, arial, helvetica, sans-serif;"><strong><span style="font-size: 9pt;">*** <span style="text-decoration: underline;">GIT COMMIT DETAILS </span>***</span></strong></span></td>
</tr>
<tr style="height: 18px;">
<td style="width: 100%; height: 18px;"><span style="font-family: 'courier new', courier;"><strong><span style="font-size: 9pt;">"""+(git_commit_det.replace(' ', '<br>'))+"""</span></strong></span></td>
</tr>
</tbody>
</table>
<div>&nbsp;</div>
<table style="border-collapse: collapse; width: 89.0977%; height: 36px;" border="1">
<tbody>
<tr style="height: 19px;">
<td style="width: 100%; text-align: center; height: 19px;"><span style="font-family: tahoma, arial, helvetica, sans-serif;"><span style="font-size: 9pt;"><strong>*** </strong></span><span style="font-size: 9pt;"><span style="text-decoration: underline;"><strong>JENKINS PIPELINE LOG</strong></span><strong>&nbsp; ***</strong></span></span></td>
</tr>
<tr style="height: 18px;">
<td style="width: 100%; height: 17px;"><span style="font-size: 9pt; background-color: #c9f2c9; font-family: 'courier new', courier;">"""+(build_logs)+"""</span></td>
</tr>
</tbody>
</table>
<p><span style="font-size: 12.0pt; font-family: 'Times New Roman',serif;">***This is an Auto-generated email for a successful Jenkins deployment.</span></p>
<p><span style="font-size: 10.0pt;">Thanks &amp; Regards,</span></p>
<p><span style="font-size: 10.0pt;">MTIS-Applications And Platform Support | DAP Operation Team</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>"""
  elif(status=="prod-success"):

      SUBJECT = "SUCCESS - JENKINS {} RELEASE-{} JOB-{}".format(build_name, tag_version, jenkins_no)
      BODY_HTML = """<p>Hello,</p>
<p>Jenkins pipeline has been deployed successfully. Please find the details below.</p>
<div><span style="font-family: tahoma, arial, helvetica, sans-serif;"><strong><span style="font-size: 9pt;">Jenkins Build No: """+(jenkins_no)+"""</span></strong></span></div>
<p><span style="font-family: tahoma, arial, helvetica, sans-serif;"><strong><span style="font-size: 9pt;">Jenkins Job URL: """+(jenkins_url)+"""</span></strong></span></p>
<p><span style="font-family: tahoma, arial, helvetica, sans-serif;"><strong><span style="font-size: 9pt;">GitHub Release Version: """+(tag_version)+"""</span></strong></span></p>
<table style="border-collapse: collapse; width: 88.7564%; height: 40px;" border="1">
<tbody>
<tr style="height: 22px;">
<td style="width: 100%; text-align: center; height: 22px;"><span style="font-family: tahoma, arial, helvetica, sans-serif;"><strong><span style="font-size: 9pt;">*** <span style="text-decoration: underline;">GIT COMMIT DETAILS </span>***</span></strong></span></td>
</tr>
<tr style="height: 18px;">
<td style="width: 100%; height: 18px;"><span style="font-family: 'courier new', courier;"><strong><span style="font-size: 9pt;">"""+(git_commit_det.replace(' ', '<br>'))+"""</span></strong></span></td>
</tr>
</tbody>
</table>
<div>&nbsp;</div>
<table style="border-collapse: collapse; width: 89.0977%; height: 36px;" border="1">
<tbody>
<tr style="height: 19px;">
<td style="width: 100%; text-align: center; height: 19px;"><span style="font-family: tahoma, arial, helvetica, sans-serif;"><span style="font-size: 9pt;"><strong>*** </strong></span><span style="font-size: 9pt;"><span style="text-decoration: underline;"><strong>JENKINS PIPELINE LOG</strong></span><strong>&nbsp; ***</strong></span></span></td>
</tr>
<tr style="height: 18px;">
<td style="width: 100%; height: 17px;"><span style="font-size: 9pt; background-color: #c9f2c9; font-family: 'courier new', courier;">"""+(build_logs)+"""</span></td>
</tr>
</tbody>
</table>
<p><span style="font-size: 12.0pt; font-family: 'Times New Roman',serif;">***This is an Auto-generated email for a successful Jenkins deployment.</span></p>
<p><span style="font-size: 10.0pt;">Thanks &amp; Regards,</span></p>
<p><span style="font-size: 10.0pt;">MTIS-Applications And Platform Support | DAP Operation Team</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>"""
  
  else:
      logger.debug("Status not provided for sending email, ignoring...")

  # The character encoding for the email.
  CHARSET = "UTF-8"

  # Create a new SES resource and specify a region.
  client = session.client('ses')

  # Try to send the email.
  try:
    #Provide the contents of the email.
    response = client.send_email(
        Destination={
            'ToAddresses': [
                dl_email,
            ],
            'BccAddresses': [
                'DAPOnsiteOffshore@hbo.com',
            ],
        },
        Message={
            'Body': {
                'Html': {
                    'Charset': CHARSET,
                    'Data': BODY_HTML,
                },
            },
            'Subject': {
                'Charset': CHARSET,
                'Data': SUBJECT,
            },
        },
        Source='DAPOperationsSupport@hbo.com',
    )

  # Display an error if something goes wrong.
  except ClientError as e:
    logger.error("An error occured while sending email to DAP Admin & Suppport. Error Response: {}".format(e.response['Error']['Message']))
  else:
    logger.debug("Email sent to DAP Admin & Support! Message ID: {}".format(response['MessageId']))


def main():
  init_logger()
  options=args_parse()
  send_email(options.env, options.git_branch, options.commit_details, options.jenkins_url, options.build_no, options.build_name, options.build_logs, options.build_status, options.email, options.tag_version)

if __name__ == '__main__':
       main()

sys.exit()
