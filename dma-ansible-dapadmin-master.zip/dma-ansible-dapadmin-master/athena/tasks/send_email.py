#!/bin/python

####Python script to send email using SES####

import sys
import boto3
from botocore.exceptions import ClientError


SENDER = "DAPOperationsSupport@hbo.com"
DLRECIPIENT = "nidhin.nairru@hbo.com"
RECIPIENT = sys.argv[1]
DATABASE = sys.argv[2]
TABLE = sys.argv[3]
ENV = sys.argv[4] 
STATUS = sys.argv[5]

ENVIRONMENT = ENV.capitalize()
# The subject line for the email.

#Checking status of the athena table creation
if (STATUS == "success"): 
   SUBJECT = "SUCCESS: {} Athena-Deployment for Database '{}'".format(ENVIRONMENT,DATABASE)

   # The HTML body of the email.
   BODY_HTML = """<p><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">Hi,</span></p>
<p><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">&nbsp; &nbsp; Athena code for Database '%s' and Table '%s' has been deployed to %s environment successfully.</span></p>
<p><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">Thanks &amp; Regards,</span><br /><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">MTIS-Applications And Platform Support | DAP Operations Team</span></p>"""  %(DATABASE,TABLE,ENVIRONMENT)
else:
   SUBJECT = "FAILED: {} Athena-Deployment for Database '{}'".format(ENVIRONMENT,DATABASE)

   # The HTML body of the email.
   BODY_HTML = """<p><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">Hi,</span></p>
<p><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">&nbsp; &nbsp; Athena code deployment for Database '%s' and Table '%s' has failed in %s environment. Please review the error in Jenkins pipeline.</span></p>
<p><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">Thanks &amp; Regards,</span><br /><span style="font-size: 9.0pt; font-family: 'Verdana',sans-serif;">MTIS-Applications And Platform Support | DAP Operations Team</span></p>"""  %(DATABASE,TABLE,ENVIRONMENT)

# The character encoding for the email.
CHARSET = "UTF-8"

# Create a new SES resource and specify a region.
client = boto3.client('ses',region_name="us-east-1")

# Try to send the email.
try:
    #Provide the contents of the email.
    response = client.send_email(
        Destination={
            'ToAddresses': [
                RECIPIENT,
            ],
            'BccAddresses': [
                DLRECIPIENT,
            ],
        },
       Message={
            'Body': {
                'Html': {
                    'Charset': CHARSET,
                    'Data': BODY_HTML,
                },
            },
            'Subject': {
                'Charset': CHARSET,
                'Data': SUBJECT,
            },
        },
        Source=SENDER,
    )

# Display an error if something goes wrong.	
except ClientError as e:
    print(e.response['Error']['Message'])
else:
    print("Email sent! Message ID:"),
    print(response['MessageId'])


sys.exit()
