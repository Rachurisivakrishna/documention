#!/bin/python


import boto3
import sys


athena = boto3.client('athena')


def poll_status(_id):
    """
    poll query status
    """
    result = athena.get_query_execution(
        QueryExecutionId=_id
    )
    state = result['QueryExecution']['Status']['State']
    if state == 'RUNNING':
        return result
    elif state == 'FAILED':
        return result
    else:
        raise Exception


def query_to_athena(FILE_NAME,DATABASE_NAME,S3BUCKET_NAME,ENV):
    f = open(FILE_NAME,"r")
    lines = f.readlines()
    f.close()
    f = open("FILE_NAME","w")
    for line in lines:
       if '--' not in line:
            f.write(line)
    f.close()    
    with open(FILE_NAME, 'r') as f:
        Queryread=f.read()
        if ENV=="prod":
             sql_query=(Queryread.replace("-{env}", ""))
        else:
             sql_query=(Queryread.replace("-{env}", "-dev"))
        result = athena.start_query_execution(
            QueryString=sql_query,
            QueryExecutionContext={
                'Database': DATABASE_NAME
            },
            ResultConfiguration={
                'OutputLocation': 's3://{0}/'.format(S3BUCKET_NAME)
            }
        )
    QueryExecutionId = result['QueryExecutionId']
    print(QueryExecutionId)
    result = poll_status(QueryExecutionId)
    if result['QueryExecution']['Status']['State'] == 'SUCCEEDED':
        return 0
    elif result['QueryExecution']['Status']['State'] == 'FAILED':
        return -1



def main():
    FILE_NAME=sys.argv[1]
    S3BUCKET_NAME=sys.argv[2]
    DATABASE_NAME=sys.argv[3] 
    ENV=sys.argv[4]
    return query_to_athena(FILE_NAME,DATABASE_NAME,S3BUCKET_NAME,ENV)


if __name__ == "__main__":
    sys.exit(main())
