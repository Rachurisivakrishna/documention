#!/bin/python
''' Script to collect updated files from the recent git commits and inititate ansible playbooks '''

import os
import sys

environ=sys.argv[1]
email_id=sys.argv[2]
workspace=sys.argv[3]
workdirectory=sys.argv[4]

def main():
   dbfile = open(workdirectory, "r")
   for line in dbfile:
       database, table = os.path.split(line) 
       table_name = table.replace(".sql","")
       print("-"*35)
       print("Database Name: {}".format(database))
       print("Table Name:  {}".format(table_name))
       print("-"*35)
       if (".sql" in table):
               if environ=="dev":
                    os.system('ansible-playbook ./dma-ansible-dapadmin/athena/athena_table_pipeline.yml -e "database={} table_name={} env=dev workspace={} receiver_email={}"'.format(database, table_name, workspace, email_id))
               else: 
                    os.system('AWS_PROFILE=prod ansible-playbook ./dma-ansible-dapadmin/athena/athena_table_pipeline.yml -e "database={} table_name={} env=prod workspace={} receiver_email={}"'.format(database, table_name, workspace, email_id))		
       else:
               print("*********Exception:Unable to find the db sql query, pipeline will be terminated")

   dbfile.close()

if __name__ == '__main__':
          main()

sys.exit()
